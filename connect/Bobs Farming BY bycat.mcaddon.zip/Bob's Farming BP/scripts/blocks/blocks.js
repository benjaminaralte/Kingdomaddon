import { BlockPermutation, EquipmentSlot, GameMode, ItemStack, system, world, } from '@minecraft/server';
import ScriptingModule from '../scriptingModule';
import WBVector3 from '../util/wbVector3';
import { mulberryPRNG } from '../util/random';
import { getItemInSlot } from '../util/utils';
const lockedLocations = [];
const COUNTABLE_BLOCKS = [];
const PLACEABLE_ON_WATER_BLOCKS = [];
const ITEM_PICK_BLOCKS = [
    // [include] farming ...
    { block: 'twb_farm:birthday_cake', item: 'twb_farm:birthday_cake_item', },
    { block: 'twb_farm:pizza', item: 'twb_farm:pizza_item', },
    { block: 'twb_farm:pineapple_pizza', item: 'twb_farm:pineapple_pizza_item', },
    { block: 'twb_farm:jar', item: 'twb_farm:jar_item', },
    { block: 'twb_farm:fruit_smoothie', item: 'twb_farm:fruit_smoothie_item', },
    { block: 'twb_farm:green_smoothie', item: 'twb_farm:green_smoothie_item', },
    { block: 'twb_farm:jar_water', item: 'twb_farm:jar_water_item', },
    { block: 'twb_farm:peanut_butter', item: 'twb_farm:peanut_butter_item', },
    { block: 'twb_farm:tomato_sauce', item: 'twb_farm:tomato_sauce_item', },
    { block: 'twb_farm:strawberry_jam', item: 'twb_farm:strawberry_jam_item', },
    { block: 'twb_farm:pancakes', item: 'twb_farm:pancakes_item', },
    { block: 'twb_farm:cooking_pot', item: 'twb_farm:cooking_pot_item', },
    // ...
    { block: 'twb_farm:banana_bottom', item: 'twb_farm:banana_seeds', },
    { block: 'twb_farm:banana_top', item: 'twb_farm:banana_seeds', },
    { block: 'twb_farm:pineapple_plant', item: 'twb_farm:pineapple_seeds', },
    { block: 'twb_farm:pineapple', item: 'twb_farm:pineapple_item', },
    { block: 'twb_farm:corn_bottom', item: 'twb_farm:corn_seeds', },
    { block: 'twb_farm:corn_top', item: 'twb_farm:corn_seeds', },
    { block: 'twb_farm:broccoli', item: 'twb_farm:broccoli_seeds', },
    { block: 'twb_farm:cabbage', item: 'twb_farm:cabbage_seeds', },
    { block: 'twb_farm:chili', item: 'twb_farm:chili_seeds', },
    { block: 'twb_farm:cauliflower', item: 'twb_farm:cauliflower_seeds', },
    { block: 'twb_farm:eggplant', item: 'twb_farm:eggplant_seeds', },
    { block: 'twb_farm:garlic', item: 'twb_farm:garlic_item', },
    { block: 'twb_farm:grape', item: 'twb_farm:grape_seeds', },
    { block: 'twb_farm:leek', item: 'twb_farm:leek_item', },
    { block: 'twb_farm:onion', item: 'twb_farm:onion_item', },
    { block: 'twb_farm:peanut', item: 'twb_farm:peanut_item', },
    { block: 'twb_farm:rice', item: 'twb_farm:rice_item', },
    { block: 'twb_farm:spinach', item: 'twb_farm:spinach_seeds', },
    { block: 'twb_farm:strawberry', item: 'twb_farm:strawberry_seeds', },
    { block: 'twb_farm:tomato', item: 'twb_farm:tomato_seeds', },
    { block: 'twb_farm:campfire', item: 'minecraft:campfire', },
    { block: 'twb_farm:soul_campfire', item: 'minecraft:soul_campfire', }, // [include] cooking_pot farming
];
const BLOCK_ENTITIES = [
    // [include] farming ...
    {
        block: 'twb_farm:tractor_item',
        entity: 'twb_farm:tractor'
    },
    {
        block: 'twb_farm:quad_item',
        entity: 'twb_farm:quad'
    },
    {
        block: 'twb_farm:dirt_bike_item',
        entity: 'twb_farm:dirt_bike'
    },
    // ...
];
export default class BlockModule extends ScriptingModule {
    constructor() {
        super('BlockModule');
    }
    onInitialize() {
        world.beforeEvents.itemUseOn.subscribe((e) => {
            const location = WBVector3.fromMC(e.block.location);
            // Check that lock is not acquired, return otherwise
            for (const lock of lockedLocations) {
                if (location.equals(lock))
                    return;
            }
            // For each custom block...
            for (const blockName of COUNTABLE_BLOCKS) {
                // For the first 3 states out of 4...
                for (let i = 1; i <= 3; i++) {
                    // If block matches this state...
                    // eslint-disable-next-line @typescript-eslint/naming-convention
                    if (e.block.permutation.matches(blockName.block, {
                        'twb_farm:count': i,
                    })) {
                        // Acquire lock
                        lockedLocations.push(location);
                        // Update world
                        system.runTimeout(() => {
                            try {
                                const equipment = e.source.getComponent('minecraft:equippable');
                                const selectedItem = equipment.getEquipment(EquipmentSlot.Mainhand);
                                // Make sure the user is holding the right item
                                if (!selectedItem || selectedItem.typeId !== blockName.item)
                                    return;
                                // Replace block
                                e.block.setPermutation(
                                // eslint-disable-next-line @typescript-eslint/naming-convention
                                BlockPermutation.resolve(blockName.block, {
                                    'twb_farm:count': i + 1,
                                }));
                                // Play sound
                                e.source.playSound(blockName.sound, {
                                    volume: 0.5,
                                });
                                // Return here if player is in creative
                                if (world.getPlayers({ gameMode: GameMode.creative })
                                    .filter((p) => p.id === e.source.id)[0])
                                    return;
                                // Reduce item stack
                                if (selectedItem.amount > 1) {
                                    selectedItem.amount -= 1;
                                    equipment.setEquipment(EquipmentSlot.Mainhand, selectedItem);
                                }
                                else {
                                    equipment.setEquipment(EquipmentSlot.Mainhand, undefined);
                                }
                            }
                            finally {
                                // Release lock
                                for (let lockIdx = 0; lockIdx < lockedLocations.length; lockIdx++) {
                                    if (location.equals(lockedLocations[lockIdx])) {
                                        lockedLocations.splice(lockIdx, 1);
                                        break;
                                    }
                                }
                            }
                        });
                        return;
                    }
                }
            }
        });
        world.afterEvents.playerPlaceBlock.subscribe((e) => {
            const { location } = e.block;
            for (const entity of Object.values(BLOCK_ENTITIES)) {
                if (e.block.permutation.matches(entity.block)) {
                    e.player.runCommandAsync(`summon ${entity.entity} ${location.x} ${location.y} ${location.z} 180 0 minecraft:entity_spawned §r`);
                    e.block.dimension.runCommandAsync(`setblock ${location.x} ${location.y} ${location.z} air`);
                }
            }
        });
        world.afterEvents.itemUseOn.subscribe((e) => {
            for (const placeable of PLACEABLE_ON_WATER_BLOCKS) {
                if (placeable.item === e.itemStack.typeId) {
                    const block = e.block.above();
                    if (block === undefined)
                        return;
                    e.source.playSound(placeable.sound, {
                        volume: 0.5,
                    });
                    if (!block.permutation.matches('minecraft:air'))
                        return;
                    if (placeable.randomlyRotate) {
                        const random = mulberryPRNG(block.x * 123456 + block.y * 7 + block.z);
                        const facing = Math.floor(random() * 4);
                        // eslint-disable-next-line @typescript-eslint/naming-convention
                        block.setPermutation(BlockPermutation.resolve(placeable.block, {
                            'twb_farm:facing': facing,
                        }));
                    }
                    else {
                        block.setPermutation(BlockPermutation.resolve(placeable.block));
                    }
                    const equipment = e.source.getComponent('minecraft:equippable');
                    const selectedItem = equipment.getEquipment(EquipmentSlot.Mainhand);
                    if (!selectedItem || selectedItem.typeId !== placeable.item)
                        return;
                    // Return here if player is in creative
                    if (world.getPlayers({ gameMode: GameMode.creative })
                        .filter((p) => p.id === e.source.id)[0])
                        return;
                    // Reduce item stack
                    if (selectedItem.amount > 1) {
                        selectedItem.amount -= 1;
                        equipment.setEquipment(EquipmentSlot.Mainhand, selectedItem);
                    }
                    else {
                        equipment.setEquipment(EquipmentSlot.Mainhand, undefined);
                    }
                    return;
                }
            }
        });
        world.beforeEvents.playerBreakBlock.subscribe((event) => {
        });
    }
    onTick() {
        const players = world.getPlayers();
        players.forEach((player) => {
            this.blockPick(player);
        });
    }
    blockPick(player) {
        const mainhandTypeId = getItemInSlot(player, EquipmentSlot.Mainhand)?.typeId;
        const equipment = player.getComponent('minecraft:equippable');
        for (const pick of ITEM_PICK_BLOCKS) {
            if (pick.block === mainhandTypeId) {
                equipment.setEquipment(EquipmentSlot.Mainhand, new ItemStack(pick.item, 1));
                break;
            }
        }
    }
}
