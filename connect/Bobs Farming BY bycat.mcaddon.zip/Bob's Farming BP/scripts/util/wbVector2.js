import { degToRad, radToDeg } from './utils';
export default class WBVector2 {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
    static fromMC(vec2) {
        return new WBVector2(vec2.x, vec2.y);
    }
    add(other) {
        return new WBVector2(this.x + other.x, this.y + other.y);
    }
    subtract(other) {
        return new WBVector2(this.x - other.x, this.y - other.y);
    }
    multiply(value) {
        return new WBVector2(this.x * value, this.y * value);
    }
    length() {
        return Math.sqrt(this.x ** 2 + this.y ** 2);
    }
    rotate(degrees) {
        const angle = degToRad(degrees);
        return new WBVector2(this.x * Math.cos(angle) - this.y * Math.sin(angle), this.x * Math.sin(angle) + this.y * Math.cos(angle));
    }
    angle() {
        return radToDeg(Math.acos(this.x / Math.sqrt(this.x * this.x + this.y * this.y))
            * (this.y / Math.abs(this.y)));
    }
    roundAll() {
        return new WBVector2(Math.round(this.x), Math.round(this.y));
    }
    floorAll() {
        return new WBVector2(Math.floor(this.x), Math.floor(this.y));
    }
    ceilAll() {
        return new WBVector2(Math.ceil(this.x), Math.ceil(this.y));
    }
    abs() {
        return new WBVector2(Math.abs(this.x), Math.abs(this.y));
    }
    equals(other) {
        return this.x === other.x && this.y === other.y;
    }
    toString() {
        return `Vec2(${this.x}, ${this.y})`;
    }
}
