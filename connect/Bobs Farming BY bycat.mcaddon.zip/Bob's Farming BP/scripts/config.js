// eslint-disable-next-line import/no-mutable-exports, @typescript-eslint/naming-convention
let IS_ADDON = true;
export default IS_ADDON;
