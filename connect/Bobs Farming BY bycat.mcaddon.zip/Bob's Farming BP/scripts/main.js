import { system } from '@minecraft/server';
import BlockModule from './blocks/blocks'; // [include] generation farming common_crop
import CropsModule from './crops/cropsModule'; // [include] farming common_crop
import CookingPotModule from './cooking_pot/cookingPotModule'; // [include] farming cooking_pot
import FormModule from './forms/formsModule'; // [include] FormsModule addon
import FoodEffectsModule from './food_effects/foodEffectsModule'; // [include] farming cooking_pot
const modules = [
    new BlockModule(),
    new CropsModule(),
    new CookingPotModule(),
    new FormModule(),
    new FoodEffectsModule(), // [include] farming cooking_pot
];
function registerScriptingModuleInterval(ticks, callback) {
    system.runInterval(() => {
        modules.forEach((module) => {
            try {
                callback(module);
            }
            catch (error) {
                // Print the error message and stack trace
                console.error(`[${module.constructor.name}] Error:`);
                throw error;
            }
        });
    }, ticks);
}
modules.forEach((module) => {
    module.initialize();
});
registerScriptingModuleInterval(1, (module) => module.onTick?.());
registerScriptingModuleInterval(2, (module) => module.onTwoTick?.());
registerScriptingModuleInterval(5, (module) => module.onQuarterSecond?.());
registerScriptingModuleInterval(10, (module) => module.onHalfSecond?.());
registerScriptingModuleInterval(20, (module) => module.onSecond?.());
registerScriptingModuleInterval(60, (module) => module.on3Seconds?.());
registerScriptingModuleInterval(600, (module) => module.onHalfMinute?.());
registerScriptingModuleInterval(1200, (module) => module.onMinute?.());
