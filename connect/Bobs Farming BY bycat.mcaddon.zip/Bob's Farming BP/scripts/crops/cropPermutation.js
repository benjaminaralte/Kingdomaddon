import { BlockPermutation, system } from '@minecraft/server';
import { CropExtendType } from './cropLibrary';
import WBVector3 from '../util/wbVector3';
import { getRandomChoice, shuffleArray } from '../util/random';
import CropStorage from './cropStorage';
export var GrowthSource;
(function (GrowthSource) {
    GrowthSource[GrowthSource["RANDOM_TICK"] = 1] = "RANDOM_TICK";
    GrowthSource[GrowthSource["BONE_MEAL"] = 2] = "BONE_MEAL";
    GrowthSource[GrowthSource["PROPAGATION"] = 3] = "PROPAGATION";
})(GrowthSource || (GrowthSource = {}));
export default class CropPermutation {
    constructor(permutation, data) {
        this.permutation = permutation;
        this.isUpper = false;
        this.dirty = false;
        this.options = data.options;
        this.blockId = data.blockId;
        this.isUpper = data.isUpper;
    }
    getPermutation() {
        return this.permutation;
    }
    /**
     * Get the current growth stage of the crop
     * @returns The current growth stage
     */
    getGrowth() {
        return this.permutation.getState(this.stateNames.GROWTH);
    }
    /**
     * Get the final growth stage of the crop
     * @returns The last growth stage
     */
    getMaxGrowth() {
        return this.options.stages;
    }
    addGrowth(amount) {
        const currentStage = this.getGrowth();
        const newStage = Math.min(currentStage + (amount ?? 1), this.getMaxGrowth());
        if (currentStage !== newStage)
            this.dirty = true;
        this.permutation = this.permutation.withState(this.stateNames.GROWTH, newStage);
        return newStage;
    }
    setGrowth(amount) {
        const currentStage = this.getGrowth();
        const newStage = Math.min(amount, this.getMaxGrowth());
        if (currentStage !== newStage)
            this.dirty = true;
        this.permutation = this.permutation.withState(this.stateNames.GROWTH, newStage);
        return newStage;
    }
    isFullyGrown() {
        return this.getGrowth() >= this.getMaxGrowth();
    }
    getGrowDirection() {
        return this.permutation.getState(this.stateNames.DIRECTION);
    }
    setGrowDirection(direction) {
        const newDirection = (direction === null)
            ? 0
            : direction + 1;
        if (this.getGrowDirection() !== newDirection) {
            this.permutation = this.permutation.withState(this.stateNames.DIRECTION, newDirection);
            this.dirty = true;
        }
    }
    getGrowHeight() {
        return this.permutation.getState(this.stateNames.HEIGHT);
    }
    getMaxGrowHeight() {
        if (this.options.extend?.type === CropExtendType.REPEATED) {
            return this.options.extend.heightLimit;
        }
        return 1;
    }
    setGrowHeight(height) {
        const newHeight = Math.min(height, this.getMaxGrowHeight());
        if (this.getGrowHeight() !== newHeight) {
            this.permutation = this.permutation.withState(this.stateNames.HEIGHT, newHeight);
            this.dirty = true;
        }
    }
    isAffectedByScythe() {
        return this.isFullyGrown() && this.options.ignoreScythes !== true;
    }
    update(block, source, options) {
        let wasUpdated = false;
        if (this.dirty) {
            block.setPermutation(this.permutation);
            wasUpdated = true;
        }
        if (source && source !== GrowthSource.PROPAGATION) {
            const forcePropagate = source !== GrowthSource.BONE_MEAL || this.dirty;
            if (this.options.extend && (forcePropagate || this.options.extend.canUseBonemeal)) {
                switch (this.options.extend.type) {
                    case CropExtendType.SYNCRHONIZED:
                        wasUpdated = this.extendCropSynchronously(block, options) || wasUpdated;
                        break;
                    case CropExtendType.ASYNCHRONIZED:
                        wasUpdated = this.extendCropAsynchronously(block) || wasUpdated;
                        break;
                    case CropExtendType.REPEATED:
                        if (!this.dirty) {
                            wasUpdated = this.extendCropRepeatedly(block) || wasUpdated;
                        }
                        break;
                    default:
                        console.warn('Unexpected default case while handling crop extension');
                }
            }
            if (this.options.placer
                && !this.dirty
                && (this.options.placer.canUseBonemeal || forcePropagate)) {
                wasUpdated = this.placeBlockAroundCrop(block) || wasUpdated;
            }
        }
        if (wasUpdated && options?.spawnParticles) {
            block.dimension.spawnParticle('minecraft:crop_growth_emitter', block.center());
        }
        this.dirty = false;
        return wasUpdated;
    }
    extendCropSynchronously(block, options) {
        const newStage = this.getGrowth();
        const extendOptions = this.options.extend;
        if (newStage >= extendOptions.createAfterStage) {
            const topBlock = block.above();
            if (topBlock) {
                if (topBlock.permutation.matches('minecraft:air')) {
                    topBlock.setPermutation(BlockPermutation.resolve(extendOptions.typeId, {
                        [this.stateNames.GROWTH]: newStage,
                    }));
                    return true;
                }
                const topCrop = this.resolveUpper(topBlock.permutation);
                if (topCrop) {
                    topCrop.setGrowth(newStage);
                    topCrop.update(topBlock, GrowthSource.PROPAGATION, options);
                }
            }
        }
        return false;
    }
    extendCropAsynchronously(block) {
        const newStage = this.getGrowth();
        const extendOptions = this.options.extend;
        if (newStage >= extendOptions.createAfterStage) {
            const topBlock = block.above();
            if (topBlock?.permutation.matches('minecraft:air')) {
                topBlock.setPermutation(BlockPermutation.resolve(extendOptions.typeId, {
                    [this.stateNames.GROWTH]: extendOptions.initialStage,
                }));
                if (extendOptions.register) {
                    new CropStorage().registerCropLocation(topBlock.location, system.currentTick);
                }
                return true;
            }
        }
        return false;
    }
    extendCropRepeatedly(block) {
        const extendOptions = this.options.extend;
        const currentHeight = this.getGrowHeight();
        if (!currentHeight || currentHeight >= extendOptions.heightLimit)
            return false;
        const topBlock = block.above();
        if (topBlock?.permutation.matches('minecraft:air')) {
            const permutation = block.permutation
                .withState(this.stateNames.GROWTH, extendOptions.initialStage)
                .withState(this.stateNames.HEIGHT, currentHeight + 1);
            topBlock.setPermutation(permutation);
            return true;
        }
        return false;
    }
    placeBlockAroundCrop(block) {
        const placerOptions = this.options.placer;
        if (block.permutation.getState(this.stateNames.DIRECTION) !== 0)
            return false;
        const unit = new WBVector3(1, 0, 0);
        const directions = [1, 2, 3, 4];
        shuffleArray(directions);
        // Iterate over all 4 directions in random order
        for (const direction of directions) {
            const offset = unit.rotateY(direction * 90);
            const neighbor = block.dimension.getBlock(offset.add(block.location));
            // Check if neighboring block is air
            if (neighbor?.permutation.matches('minecraft:air')) {
                const belowNeighbor = neighbor.below();
                // Check if block below neighbor is valid farmland
                if (belowNeighbor
                    && (belowNeighbor.permutation.matches('minecraft:grass')
                        || belowNeighbor.permutation.matches('minecraft:farmland')
                        || belowNeighbor.permutation.matches('minecraft:dirt'))) {
                    // Place neighboring block
                    neighbor.setPermutation(getRandomChoice(placerOptions.permutations));
                    // Make the crop grow into the block's direction
                    block.setPermutation(block.permutation.withState(this.stateNames.DIRECTION, direction));
                    return true;
                }
            }
        }
        return false;
    }
}
