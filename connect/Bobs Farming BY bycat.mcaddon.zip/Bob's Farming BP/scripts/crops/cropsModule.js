/* eslint-disable no-continue */
import { BlockPermutation, system, world, ItemStack, EquipmentSlot, DimensionTypes, } from '@minecraft/server';
import ScriptingModule from '../scriptingModule';
import CropStorage from './cropStorage';
import { getRandomRange } from '../util/random';
import WBVector3 from '../util/wbVector3';
import WBVector2 from '../util/wbVector2';
import { countItemsInInventory, decreaseItemAmountInHand, decreaseItemDurabilityInHand, getItemInSlot, setItemInSlot, translate } from '../util/utils';
import TractorInventory from './tractorInventory'; // [include] farming
import { GrowthSource } from './cropPermutation';
import VanillaCrop from './vanillaCrop';
import CustomCrop, { CustomCropStateNames } from './customCrop';
import CropLibrary, { CropExtendType } from './cropLibrary';
// Load crop definitions
import './config';
export default class CropsModule extends ScriptingModule {
    constructor() {
        super('CropsModule');
        this.cropStorage = new CropStorage();
        this.cropLibrary = new CropLibrary();
        this.tickingCrops = new Set();
        this.interactCooldown = new Set();
    }
    onInitialize() {
        // Load crop locations from dynamic properties (can take a while..)
        this.cropStorage.loadFromDynamicProperties();
        // Using bone meal
        world.afterEvents.itemUse.subscribe((event) => {
            const player = event.source;
            let block = player.getBlockFromViewDirection({
                includeLiquidBlocks: false,
                includePassableBlocks: true,
                maxDistance: 7,
            })?.block;
            if (!block)
                return;
            if (this.interactCooldown.has(player.name) || player.isSneaking)
                return;
            this.interactCooldown.add(player.name);
            system.runTimeout(() => this.interactCooldown.delete(player.name), 5);
            let crop = CustomCrop.resolve(block.permutation);
            // If crop is two blocks tall and the upper block is interacted with, get
            // the bottom block as well.
            if (crop?.isUpper) {
                block = block.below();
                crop = block ? crop.resolveLower(block.permutation) : undefined;
            }
            if (!crop || !block)
                return;
            const item = event.itemStack;
            if (item?.typeId === 'minecraft:bone_meal') {
                // Get current growth stage
                const stage = crop.getGrowth();
                if (!stage) {
                    console.warn('Block', crop.blockId, 'does not have twb_farm:grow_stage state but is a configured crop');
                    return;
                }
                // Calculate new stage
                crop.addGrowth(Math.floor(getRandomRange(1, 3)));
                const wasUpdated = crop.update(block, GrowthSource.BONE_MEAL, {
                    spawnParticles: true,
                });
                // Spawn particles
                if (wasUpdated) {
                    world.playSound('item.bone_meal.use', block.center());
                    decreaseItemAmountInHand(player, 1, true);
                }
            }
        });
        // FENCE CROPS System: The ability to use the seeds on a fence
        world.afterEvents.itemUse.subscribe((event) => {
            const player = event.source;
            const item = event.itemStack;
            // Return if item is not placeable on a fence
            if (!CropsModule.FENCE_CROPS.has(item.typeId))
                return;
            // Find block player is looking at
            const block = player.getBlockFromViewDirection({
                includeLiquidBlocks: false,
                includePassableBlocks: true,
                maxDistance: 7,
            })?.block;
            if (!block)
                return;
            // Return if block is not a fence
            if (!this.isFence(block.permutation)) {
                player.sendMessage(translate('twb_farm.info.fence_crops.placement'));
                return;
            }
            const crop = item.typeId.substring(0, item.typeId.lastIndexOf('_'));
            const cropBlock = block.above();
            if (!cropBlock)
                return;
            // Return if the block above the fence is already occupied
            if (!cropBlock.permutation.matches('minecraft:air')) {
                player.sendMessage(translate('twb_farm.info.fence_crops.space'));
                return;
            }
            // Place crop
            cropBlock.setPermutation(BlockPermutation.resolve(crop));
            this.cropStorage.registerCropLocation(cropBlock.location, system.currentTick);
            // Play sound
            world.playSound('dig.grass', block.location);
            // Consume seed
            decreaseItemAmountInHand(player, 1, true);
        });
        // Synchronized destruction
        world.afterEvents.playerBreakBlock.subscribe((event) => {
            const { block } = event;
            const crop = this.getCrop(event.brokenBlockPermutation);
            // Destroy lower part of tall crop
            if (crop
                && !crop.isVanilla
                && crop.isUpper
                && crop.options.extend?.type === CropExtendType.SYNCRHONIZED) {
                const loc = block.location;
                block.dimension.runCommand(`setblock ${loc.x} ${loc.y - 1} ${loc.z} air destroy`);
            }
        });
        // Scythes
        world.afterEvents.playerBreakBlock.subscribe((event) => {
            const tool = event.itemStackBeforeBreak;
            // No item used
            if (!tool)
                return;
            const options = CropsModule.SCYTHES.get(tool.typeId);
            // No scythe used
            if (!options)
                return;
            if (!this.isBlockAffectedByScythe(event.brokenBlockPermutation))
                return;
            // Decrease durability on block break
            decreaseItemDurabilityInHand(event.player);
            // Get neighboring blocks
            const { block } = event;
            const north = block.north();
            const south = block.south();
            const neighbors = [
                Math.random() < options.innerChance ? north : undefined,
                Math.random() < options.innerChance ? south : undefined,
                Math.random() < options.innerChance ? block.east() : undefined,
                Math.random() < options.innerChance ? block.west() : undefined,
                Math.random() < options.outerChance ? north?.east() : undefined,
                Math.random() < options.outerChance ? north?.west() : undefined,
                Math.random() < options.outerChance ? south?.east() : undefined,
                Math.random() < options.outerChance ? south?.west() : undefined,
            ];
            neighbors.forEach((neighbor) => {
                if (neighbor && this.isBlockAffectedByScythe(neighbor.permutation)) {
                    const crop = this.getCrop(neighbor.permutation);
                    const loc = neighbor.location;
                    const yLoc = crop?.isUpper ? loc.y - 1 : loc.y;
                    neighbor.dimension.runCommand(`setblock ${loc.x} ${yLoc} ${loc.z} air destroy`);
                }
            });
        });
        // Disconnect stem crops from destroyed blocks
        world.afterEvents.playerBreakBlock.subscribe((event) => {
            const { block, brokenBlockPermutation } = event;
            if (this.cropLibrary.getBlocksPlaceableByCrops().has(brokenBlockPermutation)) {
                // Potentially find a crop that has grown into this block, and reset its grow direction
                let neighbor = block.north();
                let crop = neighbor ? CustomCrop.resolve(neighbor.permutation) : undefined;
                if (crop?.getGrowDirection() === 1) {
                    crop.setGrowDirection(null);
                    return;
                }
                // Hardcoding this for convenience :)
                neighbor = block.east();
                crop = neighbor ? CustomCrop.resolve(neighbor.permutation) : undefined;
                if (crop?.getGrowDirection() === 2) {
                    crop.setGrowDirection(null);
                    return;
                }
                neighbor = block.south();
                crop = neighbor ? CustomCrop.resolve(neighbor.permutation) : undefined;
                if (crop?.getGrowDirection() === 3) {
                    crop.setGrowDirection(null);
                    return;
                }
                neighbor = block.west();
                crop = neighbor ? CustomCrop.resolve(neighbor.permutation) : undefined;
                if (crop?.getGrowDirection() === 4) {
                    crop.setGrowDirection(null);
                }
            }
        });
        // Set crop_height of stackable crops
        world.afterEvents.playerPlaceBlock.subscribe((event) => {
            const { block } = event;
            for (const blockId of this.cropLibrary.getRepeatedlyGrowingBlockIDs()) {
                if (block.permutation.matches(blockId)) {
                    const below = block.below();
                    if (below?.permutation.matches(blockId)) {
                        const upperCrop = this.getCrop(block.permutation);
                        const lowerCrop = this.getCrop(below.permutation);
                        upperCrop.setGrowHeight((lowerCrop.getGrowHeight() || 0) + 1);
                        upperCrop.update(block);
                    }
                    return;
                }
            }
        });
        // Still BETA, unfortunately
        /*
        // Harvest crops by interacting instead of destroying them
        world.afterEvents.playerInteractWithBlock.subscribe((event) => {
          const { player } = event;
    
          if (this.interactCooldown.has(player.name) || player.isSneaking) return;
          this.interactCooldown.add(player.name);
          system.runTimeout(() => this.interactCooldown.delete(player.name), 5);
    
          const growStage = event.block.permutation.getState(GROW_STAGE_STATE) as number;
          if (!growStage) return;
    
          const options = this.getCropOptions(event.block.permutation);
          const crop = options?.crop;
          if (crop?.pickable) {
            const { pickable } = crop;
            if (growStage >= (pickable.fromStage || crop.stages)) {
              const loc = event.block.location;
              event.player.runCommand(`loot spawn ${loc.x} ${loc.y} ${loc.z} loot "twb/farm/${pickable.lootTable}" mainhand`);
              event.block.setPermutation(
                event.block.permutation.withState(GROW_STAGE_STATE, pickable.resetToStage)
              );
              // TODO: Playsound "block.sweet_berry_bush.pick"
            }
          }
        });
        */
        // Fill empty watering cans
        world.afterEvents.itemUseOn.subscribe((event) => {
            if (event.itemStack.typeId !== 'twb_farm:watering_can_empty_item')
                return;
            if (event.block.permutation.matches('minecraft:water')) {
                // Water source blocks
                setItemInSlot(event.source, EquipmentSlot.Mainhand, new ItemStack('twb_farm:watering_can_item'));
                event.source.playSound('bucket.fill_water');
            }
            else if (event.block.permutation.matches('minecraft:cauldron', { cauldron_liquid: 'water' })) {
                // Cauldron with water
                const waterLevel = event.block.permutation.getState('fill_level');
                if (waterLevel) {
                    // Has liquid
                    event.source.playSound('bucket.fill_water');
                    setItemInSlot(event.source, EquipmentSlot.Mainhand, new ItemStack('twb_farm:watering_can_item'));
                    event.block.setPermutation(event.block.permutation.withState('fill_level', waterLevel - 1));
                }
            }
        });
        // Fill water jar
        world.afterEvents.itemUseOn.subscribe((event) => {
            if (event.itemStack.typeId !== 'twb_farm:jar_item')
                return;
            if (event.block.permutation.matches('minecraft:water')) {
                // Water source blocks
                setItemInSlot(event.source, EquipmentSlot.Mainhand, new ItemStack('twb_farm:jar_water_item'));
                event.source.playSound('bucket.fill_water');
            }
            else if (event.block.permutation.matches('minecraft:cauldron', { cauldron_liquid: 'water' })) {
                // Cauldron with water
                const waterLevel = event.block.permutation.getState('fill_level');
                if (waterLevel) {
                    // Has liquid
                    setItemInSlot(event.source, EquipmentSlot.Mainhand, new ItemStack('twb_farm:jar_water_item'));
                    event.source.playSound('bucket.fill_water');
                    event.block.setPermutation(event.block.permutation.withState('fill_level', waterLevel - 1));
                }
            }
        });
        // Add compost to watering can
        world.beforeEvents.itemUseOn.subscribe((event) => {
            if (event.source.isSneaking)
                return;
            if (!event.block.permutation.matches('minecraft:composter'))
                return;
            let fillLevel = event.block.permutation.getState('composter_fill_level');
            if (fillLevel !== 8)
                return;
            const itemStack = getItemInSlot(event.source, EquipmentSlot.Mainhand);
            if (!itemStack || itemStack.typeId !== 'twb_farm:watering_can_item')
                return;
            const durability = itemStack.getComponent('minecraft:durability');
            if (!durability)
                return;
            // Won't be available later so have to store new
            const oldDamage = durability.damage;
            const oldMaxDurability = durability.maxDurability;
            const newFillLevel = Math.floor((oldDamage / oldMaxDurability) * 7);
            // Cancel event so we don't drop any bone meal
            // eslint-disable-next-line no-param-reassign
            event.cancel = true;
            system.runTimeout(() => {
                // Update and check level again after the event to prevent any potential race conditions
                fillLevel = event.block.permutation.getState('composter_fill_level');
                if (fillLevel !== 8)
                    return;
                const newItem = new ItemStack('twb_farm:watering_can_compost_item', 1);
                const newDurability = newItem.getComponent('minecraft:durability');
                if (newDurability) {
                    const newDamage = (oldDamage / oldMaxDurability) * newDurability.maxDurability;
                    newDurability.damage = Math.round(newDamage);
                }
                setItemInSlot(event.source, EquipmentSlot.Mainhand, newItem);
                event.block.setPermutation(event.block.permutation.withState('composter_fill_level', newFillLevel));
                world.playSound('block.composter.empty', event.block.location);
            });
        });
        // Use watering can
        world.afterEvents.itemCompleteUse.subscribe((event) => {
            let doCompost;
            switch (event.itemStack.typeId) {
                case 'twb_farm:watering_can_item':
                    doCompost = false;
                    break;
                case 'twb_farm:watering_can_compost_item':
                    doCompost = true;
                    break;
                default:
                    return;
            }
            // Cancel if clicking on a composter
            // Unfortunately cannot cancel cooldown
            const block = event.source.getBlockFromViewDirection({ maxDistance: 10 });
            if (block?.block.permutation.matches('minecraft:composter'))
                return;
            this.useWateringCan(event.source, doCompost, 3);
            decreaseItemDurabilityInHand(event.source, {
                destructionSound: 'cauldron_drip.water.pointed_dripstone',
                convertInto: 'twb_farm:watering_can_empty_item'
            });
        });
        // Tractor functionality
        this.addScriptEvent('twb_farm:tractor_attachment', (e) => {
            const tractor = e.sourceEntity;
            switch (e.message) {
                case 'twb_farm:bedformer':
                    this.tractorUseBedformer(tractor);
                    return;
                case 'twb_farm:planter':
                    this.tractorUsePlanter(tractor);
                    return;
                case 'twb_farm:fertilizer':
                    this.tractorUseFertilizer(tractor);
                    return;
                case 'twb_farm:harvester':
                    this.tractorUseHarvester(tractor);
                    return;
                default:
                    console.warn(`Unknown tractor attachment "${e.message}"`);
            }
        });
        this.addScriptEvent('twb_farm:tractor_fertilizer_level', (e) => {
            const tractor = e.sourceEntity;
            const amount = countItemsInInventory(tractor, 'minecraft:bone_meal');
            let level = 3;
            if (!amount)
                level = 0;
            else if (amount < 3 * 64)
                level = 1;
            else if (amount < 9 * 64)
                level = 2;
            tractor.setProperty('twb_farm:fertilizer_level', level);
        });
        this.addScriptEvent('twb_farm:tractor_accumulate_dirt', (e) => {
            const tractor = e.sourceEntity;
            const blockLocation = WBVector3.fromMC(tractor.location).add({ x: 0, y: -0.5, z: 0 });
            const block = tractor.dimension.getBlock(blockLocation);
            if (block && (block.permutation.matches('minecraft:dirt')
                || block.permutation.matches('minecraft:grass')
                || block.permutation.matches('minecraft:farmland'))) {
                this.tractorAddDirt(tractor, 1);
            }
        });
        this.addScriptEvent('twb_farm:tractor_watering_can_used', (e) => {
            const tractor = e.sourceEntity;
            this.tractorAddDirt(tractor, -40);
        });
        this.addScriptEvent('twb_farm:tractor_equip_attachment', (e) => {
            const tractor = e.sourceEntity;
            const currentIndex = tractor.getProperty('twb_farm:attachment');
            const newIndex = CropsModule.TRACTOR_ATTACHMENTS.findIndex((att) => att === e.message);
            if (newIndex === -1) {
                console.warn(`Unknown attachment "${e.message}"`);
                return;
            }
            world.playSound('mob.irongolem.walk', tractor.location);
            if (currentIndex > 0) {
                const location = WBVector3.fromMC(tractor.location).add(new WBVector3(0, 0.2, currentIndex === 4 ? 3.0 : -3.0).rotateY(tractor.getRotation().y));
                const currentAttachment = CropsModule.TRACTOR_ATTACHMENTS[currentIndex];
                tractor.dimension.spawnItem(new ItemStack(`twb_farm:tractor_${currentAttachment}_item`), location);
            }
            tractor.setProperty('twb_farm:attachment', newIndex);
        });
        // Needs a module
        world.afterEvents.projectileHitBlock.subscribe((event) => {
            if (event.projectile.typeId === 'twb_farm:rotten_tomato') {
                event.projectile.dimension.spawnParticle('twb_farm:rotten_tomato', event.projectile.location);
                event.projectile.kill();
            }
        });
        world.afterEvents.projectileHitEntity.subscribe((event) => {
            if (event.projectile.typeId === 'twb_farm:rotten_tomato') {
                event.projectile.dimension.spawnParticle('twb_farm:rotten_tomato', event.projectile.location);
                event.projectile.kill();
            }
        });
        world.afterEvents.playerPlaceBlock.subscribe((event) => {
            const { block } = event;
            const growStage = block.permutation.getState(CustomCropStateNames.GROWTH);
            if (!growStage)
                return;
            this.cropStorage.registerCropLocation(event.block.location, system.currentTick);
        });
        world.afterEvents.playerBreakBlock.subscribe((event) => {
            const crop = CustomCrop.resolve(event.brokenBlockPermutation);
            if (!crop)
                return;
            if (crop.isUpper) {
                this.cropStorage.deregisterCropLocation({
                    x: event.block.location.x,
                    y: event.block.location.y - 1,
                    z: event.block.location.z,
                });
            }
            else {
                this.cropStorage.deregisterCropLocation(event.block.location);
            }
        });
        // Composter
        world.beforeEvents.itemUseOn.subscribe((event) => {
            if (event.source.isSneaking)
                return;
            const compostChance = CropsModule.COMPOSTABLE_ITEMS.get(event.itemStack.typeId);
            if (!compostChance)
                return;
            if (!event.block.permutation.matches('minecraft:composter'))
                return;
            // Check level before event so that we can return if player is collecting
            // bone meal from a full composter.
            let fillLevel = event.block.permutation.getState('composter_fill_level');
            if (fillLevel === undefined || fillLevel >= 7)
                return;
            system.runTimeout(() => {
                // Update and check level again after the event to prevent any potential race conditions
                fillLevel = event.block.permutation.getState('composter_fill_level');
                if (fillLevel === undefined || fillLevel >= 7)
                    return;
                decreaseItemAmountInHand(event.source, 1, true);
                event.block.dimension.spawnParticle('minecraft:crop_growth_emitter', event.block.center());
                if (Math.random() > compostChance) {
                    world.playSound('block.composter.fill', event.block.location);
                    return;
                }
                const newFillLevel = fillLevel + 1;
                event.block.setPermutation(event.block.permutation.withState('composter_fill_level', newFillLevel));
                world.playSound('block.composter.fill_success', event.block.location);
                // If at 7th stage we should set to 8th stage after a short delay
                if (newFillLevel === 7) {
                    system.runTimeout(() => {
                        // Update and check level again after the event to prevent any potential race conditions
                        fillLevel = event.block.permutation.getState('composter_fill_level');
                        if (fillLevel !== 7)
                            return;
                        event.block.setPermutation(event.block.permutation.withState('composter_fill_level', 8));
                        world.playSound('block.composter.ready', event.block.location);
                    }, 20);
                }
            });
        });
    }
    isFence(permutation) {
        return CropsModule.FENCE_BLOCKS.find((blockId) => permutation.matches(blockId));
    }
    getCrop(permutation) {
        return CustomCrop.resolve(permutation) || VanillaCrop.resolve(permutation);
    }
    getGrowthChance(ticksSinceLastUpdate) {
        const offset = ticksSinceLastUpdate - CropsModule.MIN_GROWTH_TIME;
        if (offset < 0)
            return 0;
        return CropsModule.GROWTH_RATE ** offset - 1;
    }
    isBlockAffectedByHoe(block) {
        if (block.permutation.matches('minecraft:farmland'))
            return false;
        if (!block.above()?.isAir)
            return false;
        return (block.permutation.matches('minecraft:grass')
            || block.permutation.matches('minecraft:dirt'));
    }
    canBlockBePlantedOn(block) {
        return (block.permutation.matches('minecraft:farmland')
            && !!(block.above()?.isAir));
    }
    isBlockAffectedByScythe(permutation) {
        const crop = this.getCrop(permutation);
        if (crop)
            return crop.isAffectedByScythe();
        return this.isBlockPlaceableByCrop(permutation);
    }
    isBlockPlaceableByCrop(permutation) {
        return this.cropLibrary.getBlocksPlaceableByCrops().has(permutation);
    }
    get3x3AreaAroundBlock(block) {
        const north = block.north();
        const south = block.south();
        return [
            block,
            north,
            south,
            block.east(),
            block.west(),
            north?.east(),
            north?.west(),
            south?.east(),
            south?.west(),
        ];
    }
    useWateringCan(player, doCompost, repeat) {
        const soundLocation = new WBVector3(0, 1, 2)
            .rotateY(player.getRotation().y)
            .add(player.location);
        world.playSound('twb_farm:watering_can', soundLocation, { pitch: 1.5 });
        world.playSound('twb_farm:watering_can', soundLocation, { pitch: 1.5 });
        world.playSound('twb_farm:watering_can', soundLocation, { pitch: 1.5 });
        const block = player.getBlockFromViewDirection({
            maxDistance: 9,
            includePassableBlocks: false
        })?.block;
        if (block) {
            this.get3x3AreaAroundBlock(block).forEach((n) => {
                if (!n)
                    return;
                let chanceFactor;
                if (block === n)
                    chanceFactor = (repeat ? 1.5 : 2.5);
                else
                    chanceFactor = (repeat ? 1 : 1.7);
                if (n)
                    this.pourWaterOnBlock(n, doCompost, chanceFactor);
            });
        }
        if (repeat) {
            system.runTimeout(() => this.useWateringCan(player, doCompost, repeat - 1), 5);
        }
    }
    pourWaterOnBlock(block, doCompost, chanceFactor) {
        block.dimension.spawnParticle('twb_farm:watering_can', block.center());
        let farmlandBlock = block;
        const isFence = this.isFence(block.permutation);
        // Search for farmland below
        if (!farmlandBlock.permutation.matches('minecraft:farmland')) {
            farmlandBlock = block.below();
            // Search for farmland above
            if (!farmlandBlock || !farmlandBlock.permutation.matches('minecraft:farmland')) {
                farmlandBlock = block.above();
                if (farmlandBlock && !farmlandBlock.permutation.matches('minecraft:farmland')) {
                    farmlandBlock = undefined;
                }
            }
        }
        if (farmlandBlock) {
            // Increase farmland moisturization
            const moisture = farmlandBlock.permutation.getState('moisturized_amount');
            if (moisture < 7) {
                farmlandBlock.setPermutation(farmlandBlock.permutation.withState('moisturized_amount', moisture + 1));
            }
            // If a farmland block was found and the block above is a crop (not a fence), use compost
            if (doCompost && !isFence) {
                const cropBlock = farmlandBlock.above();
                if (cropBlock) {
                    this.useCompostOnCrop(cropBlock, chanceFactor ?? 1);
                }
            }
        }
        // If a fence block was found, use compost on the associated crop
        if (doCompost && isFence) {
            const cropBlock = block.above();
            if (cropBlock) {
                this.useCompostOnCrop(cropBlock, chanceFactor ?? 1);
            }
        }
    }
    useCompostOnCrop(block, chanceFactor) {
        const crop = this.getCrop(block.permutation);
        if (!crop)
            return;
        const growth = getRandomRange(0.03, 0.07) * chanceFactor * crop.getMaxGrowth();
        crop.addGrowth(Math.round(growth + getRandomRange(0, 0.5)));
        crop.update(block, GrowthSource.BONE_MEAL, { spawnParticles: false });
    }
    tractorUseBedformer(tractor) {
        const location = WBVector3.fromMC(tractor.location).add(new WBVector3(0, -0.8, -3.0).rotateY(tractor.getRotation().y));
        let block = tractor.dimension.getBlock(location);
        if (block?.isAir) {
            block = block.below();
        }
        if (!block)
            return;
        // if (block.permutation.matches('minecraft:dirt')) {
        //   if (!block.above()?.isAir) return;
        // } else if (!block.permutation.matches('minecraft:grass')) {
        //   return;
        // }
        this.get3x3AreaAroundBlock(block).forEach((neighbor) => {
            if (neighbor) {
                if (this.isBlockAffectedByHoe(neighbor)) {
                    neighbor.setPermutation(BlockPermutation.resolve('minecraft:farmland'));
                    world.playSound('use.moss', neighbor.center());
                }
            }
        });
    }
    tractorUsePlanter(tractor) {
        const location = WBVector3.fromMC(tractor.location).add(new WBVector3(0, -0.8, -3.0).rotateY(tractor.getRotation().y));
        let block = tractor.dimension.getBlock(location);
        if (block?.isAir) {
            block = block.below();
        }
        if (!block)
            return;
        // if (block.permutation.matches('minecraft:dirt')) {
        //   if (!block.above()?.isAir) return;
        // } else if (!block.permutation.matches('minecraft:grass')) {
        //   return;
        // }
        const inventory = new TractorInventory(tractor);
        for (const neighbor of this.get3x3AreaAroundBlock(block)) {
            if (neighbor) {
                if (this.canBlockBePlantedOn(neighbor)) {
                    const blockAbove = neighbor.above();
                    if (!blockAbove)
                        continue;
                    const permutation = inventory.useSeed();
                    // If we have no seeds now, we won't have any in the remaining
                    // iterations too. So we should break.
                    if (!permutation)
                        break;
                    blockAbove.setPermutation(permutation);
                    this.cropStorage.registerCropLocation(blockAbove.location, system.currentTick);
                    world.playSound('place.moss', neighbor.center());
                }
            }
        }
    }
    tractorUseFertilizer(tractor) {
        const location = WBVector3.fromMC(tractor.location).add(new WBVector3(0, 0.2, -3.0).rotateY(tractor.getRotation().y));
        let block = tractor.dimension.getBlock(location);
        if (block?.permutation.matches('minecraft:air')) {
            const below = block.below();
            if (below?.permutation.matches('minecraft:air')) {
                block = below;
            }
        }
        else if (block?.permutation.matches('minecraft:farmland')) {
            block = block.above();
        }
        if (!block)
            return;
        const inventory = new TractorInventory(tractor);
        if (!inventory.hasBoneMeal())
            return;
        let usedBoneMeal = false;
        this.get3x3AreaAroundBlock(block).forEach((neighbor) => {
            if (neighbor) {
                const crop = this.getCrop(neighbor.permutation);
                if (crop && !crop.isFullyGrown()) {
                    const targetBlock = crop.isUpper ? neighbor.below() : neighbor;
                    if (targetBlock) {
                        if (!usedBoneMeal) {
                            inventory.useBoneMeal();
                            world.playSound('twb_farm:watering_can', neighbor.center());
                            usedBoneMeal = true;
                        }
                        this.useCompostOnCrop(targetBlock, 1);
                    }
                }
            }
        });
    }
    tractorUseHarvester(tractor) {
        const location = WBVector3.fromMC(tractor.location).add(new WBVector3(0, 0.2, 3.0).rotateY(tractor.getRotation().y));
        let block = tractor.dimension.getBlock(location);
        if (block?.permutation.matches('minecraft:air')) {
            const below = block.below();
            if (below?.permutation.matches('minecraft:air')) {
                block = below;
            }
        }
        else if (block?.permutation.matches('minecraft:farmland')) {
            block = block.above();
        }
        if (!block)
            return;
        const inventory = new TractorInventory(tractor);
        this.get3x3AreaAroundBlock(block).forEach((neighbor) => {
            if (neighbor && this.isBlockAffectedByScythe(neighbor.permutation)) {
                const crop = this.getCrop(neighbor.permutation);
                const targetBlock = crop?.isUpper ? neighbor.below() : neighbor;
                if (targetBlock) {
                    inventory.destroyBlock(targetBlock);
                    world.playSound('dig.moss', neighbor.center());
                }
            }
        });
        inventory.addItemsToInventory();
    }
    tractorAddDirt(tractor, amount) {
        const level = (tractor.getDynamicProperty('twb_farm:dirt_level') || 0);
        const newLevel = Math.min(Math.max(level + amount, 0), 100);
        let newStage = 0;
        if (newLevel >= 100)
            newStage = 3;
        else if (newLevel >= 50)
            newStage = 2;
        else if (newLevel >= 10)
            newStage = 1;
        tractor.setDynamicProperty('twb_farm:dirt_level', Math.min(newLevel, 100));
        tractor.setProperty('twb_farm:dirt_stage', newStage);
    }
    on3Seconds() {
        world.getDimension('overworld').getEntities({ type: 'twb_farm:tractor' }).forEach((e) => {
            if (e.isInWater) {
                this.tractorAddDirt(e, -40);
            }
        });
    }
    onSecond() {
        this.tickingCrops = this.cropStorage.getCropsNearPlayers(4);
    }
    onTick() {
        // Dirt bike speed ability
        DimensionTypes.getAll().forEach((dimType) => {
            const dim = world.getDimension(dimType.typeId);
            dim.getEntities({ type: 'twb_farm:dirt_bike' }).forEach((e) => {
                // Calculate their speed
                const velocity = e.getVelocity();
                const speed = new WBVector2(velocity.x, velocity.z).length();
                const wasSpeeding = e.hasTag('twb_farm:isSpeeding');
                const isSpeeding = speed > 0.3;
                if (isSpeeding) {
                    // If the bike is currently speeding...
                    const player = e.dimension.getPlayers({ closest: 1, location: e.location })[0];
                    if (player?.isJumping) {
                        // Check if the player is (still) holding down spacebar and give speed for FOV increase
                        player.addEffect('speed', 5, { amplifier: 3, showParticles: false });
                        if (!wasSpeeding) {
                            // Make bike go fast if it wasn't already
                            e.triggerEvent('twb_farm:vehicle_speed_charge');
                            e.addTag('twb_farm:isSpeeding');
                        }
                        // Stop if a player is found
                        return;
                    }
                }
                if (wasSpeeding) {
                    // Bike is no longer speeding or ridden but still has components to remove
                    e.triggerEvent('twb_farm:vehicle_speed_19');
                    e.removeTag('twb_farm:isSpeeding');
                }
            });
        });
        // Tick all crops
        const { currentTick } = system;
        for (const crop of this.tickingCrops) {
            const delta = currentTick - crop.updateTime;
            // Check if the crop should grow
            const chance = this.getGrowthChance(delta);
            if (!(Math.random() < chance))
                continue;
            // Get crop location
            // TODO: Add dimensions to crops
            const location = {
                x: crop.x,
                y: crop.y,
                z: crop.z,
            };
            const block = world.getDimension('overworld').getBlock(location);
            if (!block) {
                continue;
            }
            // Get crop data
            const cropData = CustomCrop.resolve(block.permutation);
            // If the data does not exist, there is no longer a crop here.
            // This happens when the crop is destroyed by something that was not an event
            // Examples include a command or a player removing the block below a crop
            if (!cropData) {
                this.cropStorage.deregisterCropLocation(location);
                continue;
            }
            cropData.addGrowth();
            cropData.update(block, GrowthSource.RANDOM_TICK);
            this.cropStorage.updateCropUpdateTime(crop, currentTick);
        }
    }
}
CropsModule.MIN_GROWTH_TIME = 3600;
CropsModule.GROWTH_RATE = 1.00000005;
CropsModule.COMPOSTABLE_ITEMS = new Map([
    ['twb_farm:corn_seeds', 0.30],
    ['twb_farm:banana_seeds', 0.30],
    ['twb_farm:broccoli_seeds', 0.30],
    ['twb_farm:cabbage_seeds', 0.30],
    ['twb_farm:cauliflower_seeds', 0.30],
    ['twb_farm:chili_seeds', 0.30],
    ['twb_farm:eggplant_seeds', 0.30],
    ['twb_farm:grape_seeds', 0.30],
    ['twb_farm:pineapple_seeds', 0.30],
    ['twb_farm:spinach_seeds', 0.30],
    ['twb_farm:strawberry_seeds', 0.30],
    ['twb_farm:tomato_seeds', 0.30],
    ['twb_farm:corn_item', 0.65],
    ['twb_farm:acorn_item', 0.65],
    ['twb_farm:banana_item', 0.65],
    ['twb_farm:broccoli_item', 0.65],
    ['twb_farm:cabbage_item', 0.65],
    ['twb_farm:cauliflower_item', 0.65],
    ['twb_farm:chili_item', 0.65],
    ['twb_farm:eggplant_item', 0.65],
    ['twb_farm:garlic_item', 0.65],
    ['twb_farm:grape_item', 0.65],
    ['twb_farm:leek_item', 0.65],
    ['twb_farm:onion_item', 0.65],
    ['twb_farm:peneaut_item', 0.65],
    ['twb_farm:pineapple_item', 0.65],
    ['twb_farm:spinach_item', 0.65],
    ['twb_farm:pineapple_piece_item', 0.50],
    ['twb_farm:rice_item', 0.30],
    ['twb_farm:rotten_tomato_item', 0.30],
    ['twb_farm:tomato_item', 0.65],
    ['twb_farm:peanut_item', 0.65],
    ['twb_farm:corn_item', 0.65],
    ['twb_farm:strawberry_item', 0.65],
    ['twb_farm:broccoli_roasted_item', 0.65],
    ['twb_farm:cauliflower_roasted_item', 0.65],
    ['twb_farm:eggplant_roasted_item', 0.65],
    ['twb_farm:broccoli_roasted_item', 0.65],
    ['twb_farm:cheese_item', 0.80],
    ['twb_farm:garlic_bread_item', 0.80],
    ['twb_farm:hamburger_item', 0.80],
    ['twb_farm:pancakes_item', 1],
    ['twb_farm:pbj_sandwich_item', 0.80],
    ['twb_farm:pizza_item', 0.80],
    ['twb_farm:pineapple_pizza_item', 0.80],
    ['twb_farm:sushi_item', 0.80],
]);
CropsModule.SCYTHES = new Map([
    ['twb_farm:wooden_scythe', { innerChance: 0.5, outerChance: 0 }],
    ['twb_farm:stone_scythe', { innerChance: 0.75, outerChance: 0 }],
    ['twb_farm:iron_scythe', { innerChance: 1, outerChance: 0 }],
    ['twb_farm:diamond_scythe', { innerChance: 1, outerChance: 0.5 }],
    ['twb_farm:golden_scythe', { innerChance: 1, outerChance: 0.5 }],
    ['twb_farm:netherite_scythe', { innerChance: 1, outerChance: 1 }],
]);
// [include] farming ...
CropsModule.TRACTOR_ATTACHMENTS = [
    'none',
    'bedformer',
    'planter',
    'fertilizer',
    'harvester',
];
// ...
CropsModule.FENCE_CROPS = new Set(['twb_farm:tomato_seeds', 'twb_farm:grape_seeds']);
CropsModule.FENCE_BLOCKS = [
    'minecraft:fence',
    'minecraft:warped_fence',
    'minecraft:crimson_fence',
    'minecraft:bamboo_fence',
    'minecraft:cherry_fence',
    'minecraft:nether_brick_fence',
    'minecraft:mangrove_fence',
];
