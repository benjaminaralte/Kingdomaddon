import CropPermutation from './cropPermutation';
import CropLibrary, { CropExtendType } from './cropLibrary';
export var VanillaCropStateNames;
(function (VanillaCropStateNames) {
    VanillaCropStateNames["GROWTH"] = "growth";
    VanillaCropStateNames["DIRECTION"] = "facing_direction";
    VanillaCropStateNames["HEIGHT"] = "age";
})(VanillaCropStateNames || (VanillaCropStateNames = {}));
export default class VanillaCrop extends CropPermutation {
    constructor() {
        super(...arguments);
        this.isVanilla = true;
        this.stateNames = VanillaCropStateNames;
    }
    static resolve(permutation) {
        const library = new CropLibrary();
        // Look for crop in library
        const data = library.resolve(permutation);
        if (data) {
            // When data for the crop is found...
            return data.options.isVanilla
                ? new VanillaCrop(permutation, data)
                : undefined;
        }
        const growth = permutation.getState(VanillaCropStateNames.GROWTH);
        if (growth === undefined)
            return undefined;
        library.setPermutation(permutation, VanillaCrop.DEFAULT_DATA);
        return new VanillaCrop(permutation, VanillaCrop.DEFAULT_DATA);
    }
    resolveLower(lowerPermutation) {
        if (!this.isUpper || !this.options.extend)
            return undefined;
        if (this.options.extend.type === CropExtendType.REPEATED)
            return undefined;
        return VanillaCrop.resolve(lowerPermutation);
    }
    resolveUpper(upperPermutation) {
        if (this.isUpper || !this.options.extend)
            return undefined;
        if (this.options.extend.type === CropExtendType.REPEATED)
            return undefined;
        if (!upperPermutation.matches(this.options.extend.typeId))
            return undefined;
        return VanillaCrop.resolve(upperPermutation);
    }
}
VanillaCrop.DEFAULT_DATA = {
    options: {
        isVanilla: true,
        stages: 7,
    },
    isUpper: false,
};
