/* eslint-disable max-classes-per-file */
/* eslint-disable no-bitwise */
import { world } from '@minecraft/server';
/**
 * Class to store and manage crop locations. They are stored in dynamic properties,
 * using the following format: \u0D9E<x>_<y>_<z> = time
 * Where <x>, <y> and <z> are the coordinates of the crop in base 36 (to save space).
 */
export default class CropStorage {
    constructor() {
        // Prefix character for dynamic properties for crops, U+0D9E
        this.CROP_PREFIX = '\u0D9E';
    }
    loadFromDynamicProperties() {
        try {
            const startTime = Date.now();
            const dynamicProperties = world.getDynamicPropertyIds();
            let totalCrops = 0;
            for (const property of dynamicProperties) {
                if (property.charAt(0) === this.CROP_PREFIX) {
                    // Parse crop information
                    const [uxs, ys, zs] = property.split('_');
                    const x = parseInt(uxs.slice(1), 36);
                    const y = parseInt(ys, 36);
                    const z = parseInt(zs, 36);
                    const updateTime = world.getDynamicProperty(property);
                    const crop = {
                        x, y, z, updateTime
                    };
                    // Get chunk coordinates
                    const chunkCoords = `${x >> 4}_${z >> 4}`;
                    // Add crop to map
                    const chunkCropLocations = CropStorage.cropLocations.get(chunkCoords);
                    if (chunkCropLocations)
                        chunkCropLocations.set(property, crop);
                    else
                        CropStorage.cropLocations.set(chunkCoords, new Map([[property, crop]]));
                    totalCrops++;
                }
            }
            const endTime = Date.now();
            console.log(`Loaded ${totalCrops} crop locations from dynamic properties in ${endTime - startTime}ms`);
        }
        catch (e) {
            console.error('Failed to load crop locations from dynamic properties', e);
        }
    }
    getCropsNearPlayers(chunkDistance) {
        // Get all players
        const players = world.getPlayers();
        // Get the set of all UNIQUE chunk coordinates around the players
        const uniqueChunkCoords = new Set();
        for (const player of players) {
            const chunkX = player.location.x >> 4;
            const chunkZ = player.location.z >> 4;
            for (let x = chunkX - chunkDistance; x <= chunkX + chunkDistance; x++) {
                for (let z = chunkZ - chunkDistance; z <= chunkZ + chunkDistance; z++) {
                    uniqueChunkCoords.add(`${x}_${z}`);
                }
            }
        }
        // Get the set of all crops in the unique chunk coordinates
        const crops = new Set();
        for (const chunkCoords of uniqueChunkCoords) {
            const chunkCropLocations = CropStorage.cropLocations.get(chunkCoords);
            if (chunkCropLocations) {
                for (const crop of chunkCropLocations.values()) {
                    crops.add(crop);
                }
            }
        }
        return crops;
    }
    registerCropLocation(location, placeTime) {
        // Create crop
        const crop = {
            x: location.x,
            y: location.y,
            z: location.z,
            updateTime: placeTime,
        };
        // Generate dynamic property identifier
        const property = `${this.CROP_PREFIX}${crop.x.toString(36)}_${crop.y.toString(36)}_${crop.z.toString(36)}`;
        // Get chunk coordinates
        const chunkCoords = `${crop.x >> 4}_${crop.z >> 4}`;
        // Add crop to map
        const chunkCropLocations = CropStorage.cropLocations.get(chunkCoords);
        if (chunkCropLocations)
            chunkCropLocations.set(property, crop);
        else
            CropStorage.cropLocations.set(chunkCoords, new Map([[property, crop]]));
        // Register dynamic property
        world.setDynamicProperty(property, crop.updateTime);
    }
    deregisterCropLocation(location) {
        // Generate dynamic property identifier
        const property = `${this.CROP_PREFIX}${location.x.toString(36)}_${location.y.toString(36)}_${location.z.toString(36)}`;
        // Get chunk coordinates
        const chunkCoords = `${location.x >> 4}_${location.z >> 4}`;
        // Remove crop from map
        const chunkCropLocations = CropStorage.cropLocations.get(chunkCoords);
        if (chunkCropLocations) {
            if (chunkCropLocations.delete(property)) {
                if (chunkCropLocations.size === 0) {
                    CropStorage.cropLocations.delete(chunkCoords);
                }
                world.setDynamicProperty(property, undefined);
            }
        }
    }
    updateCropUpdateTime(crop, newUpdateTime) {
        // Generate dynamic property identifier
        const property = `${this.CROP_PREFIX}${crop.x.toString(36)}_${crop.y.toString(36)}_${crop.z.toString(36)}`;
        // Update the crop object (it is a reference)
        // eslint-disable-next-line no-param-reassign
        crop.updateTime = newUpdateTime;
        // Update the dynamic property
        world.setDynamicProperty(property, newUpdateTime);
    }
}
// Maps chunk coordinates to a map of crop locations
// (x, y, z) to the last update time of that crop (in world ticks)
CropStorage.cropLocations = new Map();
