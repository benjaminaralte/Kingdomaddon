import CropPermutation from './cropPermutation';
import CropLibrary, { CropExtendType } from './cropLibrary';
export var CustomCropStateNames;
(function (CustomCropStateNames) {
    CustomCropStateNames["GROWTH"] = "twb_farm:grow_stage";
    CustomCropStateNames["DIRECTION"] = "twb_farm:grow_direction";
    CustomCropStateNames["HEIGHT"] = "twb_farm:grow_height";
})(CustomCropStateNames || (CustomCropStateNames = {}));
export default class CustomCrop extends CropPermutation {
    constructor() {
        super(...arguments);
        this.isVanilla = false;
        this.stateNames = CustomCropStateNames;
    }
    static resolve(permutation) {
        const library = new CropLibrary();
        // Look for crop in library
        const data = library.resolve(permutation);
        if (data) {
            // When data for the crop is found...
            return data.options.isVanilla
                ? undefined
                : new CustomCrop(permutation, data);
        }
        const growth = permutation.getState(CustomCropStateNames.GROWTH);
        if (growth === undefined)
            return undefined;
        library.setPermutation(permutation, CustomCrop.DEFAULT_DATA);
        return new CustomCrop(permutation, CustomCrop.DEFAULT_DATA);
    }
    resolveLower(lowerPermutation) {
        if (!this.isUpper || !this.options.extend)
            return undefined;
        if (this.options.extend.type === CropExtendType.REPEATED)
            return undefined;
        return CustomCrop.resolve(lowerPermutation);
    }
    resolveUpper(upperPermutation) {
        if (this.isUpper || !this.options.extend)
            return undefined;
        if (this.options.extend.type === CropExtendType.REPEATED)
            return undefined;
        if (!upperPermutation.matches(this.options.extend.typeId))
            return undefined;
        return CustomCrop.resolve(upperPermutation);
    }
}
CustomCrop.DEFAULT_DATA = {
    options: {
        isVanilla: false,
        stages: 4,
    },
    isUpper: false,
};
