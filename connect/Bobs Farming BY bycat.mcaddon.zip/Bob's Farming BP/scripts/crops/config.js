import { BlockPermutation } from '@minecraft/server';
import CropLibrary, { CropExtendType } from './cropLibrary';
const lib = new CropLibrary();
// [include] broccoli ...
lib.add('twb_farm:broccoli', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:broccoli_seeds',
    tractorLoot: {
        'twb_farm:broccoli_item': 1,
        'twb_farm:broccoli_seeds': 1.5,
    },
});
// ...
// [include] cabbage ...
lib.add('twb_farm:cabbage', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:cabbage_seeds',
    tractorLoot: {
        'twb_farm:cabbage_item': 1,
        'twb_farm:cabbage_seeds': 1.5,
    },
});
// ...
// [include] cauliflower ...
lib.add('twb_farm:cauliflower', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:cauliflower_seeds',
    tractorLoot: {
        'twb_farm:cauliflower_item': 1,
        'twb_farm:cauliflower_seeds': 1.5,
    },
});
// ...
// [include] pineapple ...
lib.add('twb_farm:pineapple_plant', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:pineapple_seeds',
    tractorLoot: {
        'twb_farm:pineapple_item': 1,
        'twb_farm:pineapple_seeds': 1.5,
    },
});
// ...
// [include] chili ...
lib.add('twb_farm:chili', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:chili_seeds',
    tractorLoot: {
        'twb_farm:chili_item': 1,
        'twb_farm:chili_seeds': 1.5,
    },
});
// ...
// [include] eggplant ...
lib.add('twb_farm:eggplant', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:eggplant_seeds',
    tractorLoot: {
        'twb_farm:eggplant_item': 1,
        'twb_farm:eggplant_seeds': 1.5,
    },
});
// ...
// [include] garlic ...
lib.add('twb_farm:garlic', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:garlic_item',
    tractorLoot: {
        'twb_farm:garlic_item': 1.9,
    },
});
// ...
// [include] grape ...
lib.add('twb_farm:grape', {
    isVanilla: false,
    stages: 4,
    growsOnFences: true,
    seedItem: 'twb_farm:grape_seeds',
    tractorLoot: {
        'twb_farm:grape_item': 1,
        'twb_farm:grape_seeds': 1.5,
    },
});
// ...
// [include] leek ...
lib.add('twb_farm:leek', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:leek_item',
    tractorLoot: {
        'twb_farm:leek_item': 1.9,
    },
});
// ...
// [include] onion ...
lib.add('twb_farm:onion', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:onion_item',
    tractorLoot: {
        'twb_farm:onion_item': 1.9
    },
});
// ...
// [include] peanut ...
lib.add('twb_farm:peanut', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:peanut_item',
    tractorLoot: {
        'twb_farm:peanut_item': 1.9,
    },
});
// ...
// [include] rice ...
lib.add('twb_farm:rice', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:rice_item',
    tractorLoot: {
        'twb_farm:rice_item': 1.9,
    },
});
// ...
// [include] spinach ...
lib.add('twb_farm:spinach', {
    isVanilla: false,
    stages: 4,
    seedItem: 'twb_farm:spinach_seeds',
    tractorLoot: {
        'twb_farm:spinach_item': 1,
        'twb_farm:spinach_seeds': 1.5,
    },
});
// ...
// [include] tomato ...
lib.add('twb_farm:tomato', {
    isVanilla: false,
    stages: 4,
    growsOnFences: true,
    seedItem: 'twb_farm:tomato_seeds',
    tractorLoot: {
        'twb_farm:tomato_item': 1,
        'twb_farm:tomato_seeds': 1.5,
    },
});
// ...
// [include] strawberry ...
lib.add('twb_farm:strawberry', {
    isVanilla: false,
    stages: 4,
    pickable: {
        resetToStage: 2,
        lootTable: 'crops/strawberry.loot',
    },
    seedItem: 'twb_farm:strawberry_seeds',
    tractorLoot: {
        'twb_farm:strawberry_item': 1,
        'twb_farm:strawberry_seeds': 1.5,
    },
});
// ...
// [include] corn ...
lib.add('twb_farm:corn_bottom', {
    isVanilla: false,
    stages: 4,
    extend: {
        type: CropExtendType.SYNCRHONIZED,
        canUseBonemeal: true,
        typeId: 'twb_farm:corn_top',
        createAfterStage: 3,
    },
    seedItem: 'twb_farm:corn_seeds',
    tractorLoot: {
        'twb_farm:corn_item': { min: 1, max: 3 },
        'twb_farm:corn_seeds': { min: 1, max: 2 }
    },
});
// ...
// [include] banana ...
lib.add('twb_farm:banana_bottom', {
    isVanilla: false,
    stages: 4,
    extend: {
        type: CropExtendType.SYNCRHONIZED,
        canUseBonemeal: true,
        typeId: 'twb_farm:banana_top',
        createAfterStage: 3,
    },
    seedItem: 'twb_farm:banana_seeds',
    tractorLoot: {
        'twb_farm:banana_item': 2,
        'twb_farm:banana_seeds': { min: 2, max: 3 }
    },
});
// ...
lib.add('minecraft:pumpkin_stem', {
    isVanilla: true,
    stages: 7,
    ignoreScythes: true,
    placer: {
        canUseBonemeal: false,
        permutations: [
            BlockPermutation.resolve('minecraft:pumpkin', { 'minecraft:cardinal_direction': 'north' }),
            BlockPermutation.resolve('minecraft:pumpkin', { 'minecraft:cardinal_direction': 'east' }),
            BlockPermutation.resolve('minecraft:pumpkin', { 'minecraft:cardinal_direction': 'south' }),
            BlockPermutation.resolve('minecraft:pumpkin', { 'minecraft:cardinal_direction': 'west' }),
        ]
    },
    seedItem: 'minecraft:pumpkin_seeds',
    tractorLoot: { 'minecraft:pumpkin': 1 },
});
lib.add('minecraft:melon_stem', {
    isVanilla: true,
    stages: 7,
    ignoreScythes: true,
    placer: {
        canUseBonemeal: false,
        permutations: [
            BlockPermutation.resolve('minecraft:melon_block')
        ]
    },
    seedItem: 'minecraft:melon_seeds',
});
lib.add('minecraft:beetroot', {
    isVanilla: true,
    stages: 7,
    seedItem: 'minecraft:beetroot_seeds',
    tractorLoot: {
        'minecraft:beetroot': 1.5,
        'minecraft:beetroot_seeds': 1.5,
    },
});
lib.add('minecraft:wheat', {
    isVanilla: true,
    stages: 7,
    seedItem: 'minecraft:wheat_seeds',
    tractorLoot: {
        'minecraft:wheat': 1,
        'minecraft:wheat_seeds': 1.5,
    },
});
lib.add('minecraft:torchflower_crop', {
    isVanilla: true,
    stages: 1,
    ignoreScythes: true,
});
lib.add('minecraft:carrots', {
    isVanilla: true,
    stages: 7,
    seedItem: 'minecraft:carrot',
    tractorLoot: {
        'minecraft:carrot': { min: 1, max: 4 },
    },
});
lib.add('minecraft:potatoes', {
    isVanilla: true,
    stages: 7,
    seedItem: 'minecraft:potato',
    tractorLoot: {
        'minecraft:potato': { min: 1, max: 4 },
    },
});
lib.add('minecraft:sweet_berry_bush', {
    isVanilla: true,
    stages: 3,
    seedItem: 'minecraft:sweet_berries',
    tractorLoot: {
        'minecraft:sweet_berries': { min: 2, max: 3 },
    },
});
