import { BlockPermutation, ItemStack } from '@minecraft/server';
import { getRandomRange } from '../util/random';
import { addItemToInventory, hasItemFromInventory as hasItemInInventory, removeItemFromInventory } from '../util/utils';
import CropLibrary from './cropLibrary';
import WBVector3 from '../util/wbVector3';
export default class TractorInventory {
    constructor(entity) {
        this.entity = entity;
        this.cropLibrary = new CropLibrary();
        this.inventory = new Map();
    }
    static determineAmount(range) {
        if (typeof range === 'number') {
            const floored = Math.floor(range);
            return (range - floored) > Math.random() ? floored + 1 : floored;
        }
        return Math.round(getRandomRange(range.min, range.max));
    }
    getLootTable(permutation) {
        const cropData = this.cropLibrary.getPermutation(permutation);
        return cropData?.options?.tractorLoot;
    }
    addItem(item, amount) {
        this.inventory.set(item, (this.inventory.get(item) || 0) + amount);
    }
    destroyBlock(block) {
        const loot = this.getLootTable(block.permutation);
        if (!loot)
            return;
        for (const [item, range] of Object.entries(loot)) {
            const amount = TractorInventory.determineAmount(range);
            if (amount > 0)
                this.addItem(item, amount);
        }
        block.setPermutation(TractorInventory.AIR_PERMUTATION);
    }
    addItemsToInventory() {
        const rotation = this.entity.getRotation().y;
        const spawnOffset = new WBVector3(getRandomRange(-1, 1), 0.3, 3.5).rotateY(rotation);
        for (const [item, amount] of this.inventory) {
            addItemToInventory(this.entity, new ItemStack(item, amount), {
                spawnOffset,
                spawnCallback: (entity) => {
                    entity.applyImpulse(new WBVector3(getRandomRange(-0.3, 0.3), 0.3, 0.5).rotateY(rotation));
                }
            });
        }
    }
    getContainer() {
        const inventory = this.entity.getComponent('inventory');
        return inventory.container;
    }
    useSeed() {
        const container = this.getContainer();
        for (let slotId = 0; slotId < container.size; slotId++) {
            const slot = container.getSlot(slotId);
            const item = slot.getItem();
            if (item) {
                const crop = this.cropLibrary.getBySeed(item.typeId);
                if (crop && !crop[1].growsOnFences) {
                    const permutation = BlockPermutation.resolve(crop[0]);
                    if (item.amount > 1) {
                        item.amount--;
                        container.setItem(slotId, item);
                    }
                    else {
                        container.setItem(slotId, undefined);
                    }
                    return permutation;
                }
            }
        }
        return undefined;
    }
    hasBoneMeal() {
        return hasItemInInventory(this.entity, 'minecraft:bone_meal');
    }
    useBoneMeal() {
        return removeItemFromInventory(this.entity, 'minecraft:bone_meal');
    }
}
TractorInventory.AIR_PERMUTATION = BlockPermutation.resolve('minecraft:air');
