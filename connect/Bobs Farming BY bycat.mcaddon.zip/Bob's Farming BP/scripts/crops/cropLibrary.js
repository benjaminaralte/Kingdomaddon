export var CropExtendType;
(function (CropExtendType) {
    CropExtendType[CropExtendType["SYNCRHONIZED"] = 0] = "SYNCRHONIZED";
    CropExtendType[CropExtendType["ASYNCHRONIZED"] = 1] = "ASYNCHRONIZED";
    CropExtendType[CropExtendType["REPEATED"] = 2] = "REPEATED";
})(CropExtendType || (CropExtendType = {}));
export default class CropLibrary {
    /**
     * Register a crop type.
     * @param blockId The ID of the block
     * @param crop The crop behavior associated with the block
     */
    add(blockId, crop) {
        CropLibrary.crops.set(blockId, crop);
        crop.placer?.permutations.forEach((p) => CropLibrary.placeable.add(p));
        if (crop.extend?.type === CropExtendType.REPEATED)
            CropLibrary.repeated.add(blockId);
        if (crop.seedItem)
            CropLibrary.seeds.set(crop.seedItem, [blockId, crop]);
    }
    get(blockId) {
        return CropLibrary.crops.get(blockId);
    }
    /**
     * Lookup any crop properties associated with a permutation
     * @param permutation A block permutation
     * @returns Crop data associated with this block
     */
    resolve(permutation) {
        // Check if this specific permutation is already hashed
        const crop = this.getPermutation(permutation);
        if (crop)
            return crop;
        for (const [blockId, options] of CropLibrary.crops.entries()) {
            // Check if bottom part matches
            if (permutation.matches(blockId)) {
                const data = {
                    options,
                    blockId,
                    isUpper: false
                };
                this.setPermutation(permutation, data);
                return data;
            }
            // Check if optional upper part matches
            if (options.extend && options.extend.type !== CropExtendType.REPEATED) {
                if (permutation.matches(options.extend.typeId)) {
                    const isUpper = !(options.extend.type === CropExtendType.ASYNCHRONIZED
                        && options.extend.register);
                    const data = {
                        options,
                        blockId,
                        isUpper,
                    };
                    this.setPermutation(permutation, data);
                    return data;
                }
            }
        }
        return undefined;
    }
    getPermutation(permutation) {
        return CropLibrary.permutations.get(permutation);
    }
    setPermutation(permutation, data) {
        CropLibrary.permutations.set(permutation, data);
    }
    getBySeed(itemId) {
        return CropLibrary.seeds.get(itemId);
    }
    getBlocksPlaceableByCrops() {
        return CropLibrary.placeable;
    }
    getRepeatedlyGrowingBlockIDs() {
        return CropLibrary.repeated;
    }
}
CropLibrary.crops = new Map();
// To make things more efficient, after a successful lookup, we store the block permutation
// in a hashmap to make future lookups of this specific permutation significantly faster.
CropLibrary.permutations = new Map();
CropLibrary.placeable = new Set();
CropLibrary.repeated = new Set();
CropLibrary.seeds = new Map();
