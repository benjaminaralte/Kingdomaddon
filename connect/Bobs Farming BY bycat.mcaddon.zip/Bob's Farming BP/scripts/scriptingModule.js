import { system } from '@minecraft/server';
export default class ScriptingModule {
    constructor(name) {
        this.name = name;
        this.scriptEvents = new Map();
        this.initialize = () => {
            console.log(`[${this.name}] Initializing...`);
            if (this.onInitialize) {
                try {
                    this.onInitialize();
                }
                catch (error) {
                    console.error(`[${this.name}] Error: ${error}`);
                }
                for (const [name, fn] of this.scriptEvents.entries()) {
                    system.afterEvents.scriptEventReceive.subscribe((e) => {
                        if (e.id === name)
                            fn(e);
                    });
                    console.log(`[${this.name}] Added listener for ${name} script event`);
                }
            }
            console.log(`[${this.name}] Initialized!`);
        };
    }
    addScriptEvent(name, fn) {
        this.scriptEvents.set(name, fn);
    }
}
