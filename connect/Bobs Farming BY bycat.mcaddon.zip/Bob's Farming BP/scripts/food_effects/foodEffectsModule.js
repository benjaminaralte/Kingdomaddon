import { TicksPerSecond, world } from '@minecraft/server';
import ScriptingModule from '../scriptingModule';
export default class FoodEffectsModule extends ScriptingModule {
    constructor() {
        super('FoodEffectsModule');
    }
    onInitialize() {
        world.afterEvents.itemCompleteUse.subscribe((event) => {
            const callback = FoodEffectsModule.ITEM_CALLBACKS.get(event.itemStack.typeId);
            callback?.(event.source, event.itemStack);
        });
    }
}
FoodEffectsModule.ITEM_CALLBACKS = new Map([
    [
        'twb_farm:green_smoothie_item',
        (player) => {
            player.addEffect('strength', 10 * TicksPerSecond, { amplifier: 1 });
            player.addEffect('regeneration', 4 * TicksPerSecond, { amplifier: 1 });
        }
    ],
    [
        'twb_farm:fruit_smoothie_item',
        (player) => {
            player.addEffect('speed', 15 * TicksPerSecond, { amplifier: 3 });
            player.addEffect('jump_boost', 15 * TicksPerSecond, { amplifier: 1 });
        }
    ],
    [
        'twb_farm:pbj_sandwich_item',
        (player) => {
            player.addEffect('strength', 5 * TicksPerSecond, { amplifier: 1 });
            player.addEffect('speed', 5 * TicksPerSecond, { amplifier: 1 });
        }
    ],
    [
        'twb_farm:pancakes_item',
        (player) => player.addEffect('speed', 10 * TicksPerSecond, { amplifier: 1 })
    ],
    [
        'twb_farm:chicken_delight_item',
        (player) => player.addEffect('regeneration', 5 * TicksPerSecond, { amplifier: 1 })
    ],
    [
        'twb_farm:beef_stew',
        (player) => player.addEffect('regeneration', 5 * TicksPerSecond, { amplifier: 1 })
    ],
    [
        'twb_farm:chicken_stew',
        (player) => player.addEffect('regeneration', 5 * TicksPerSecond, { amplifier: 1 })
    ],
    [
        'twb_farm:cauliflower_delight_item',
        (player) => player.addEffect('regeneration', 5 * TicksPerSecond, { amplifier: 1 })
    ],
    [
        'twb_farm:ratatouille_item',
        (player) => player.addEffect('regeneration', 5 * TicksPerSecond, { amplifier: 1 })
    ],
    [
        'twb_farm:fried_rice_item',
        (player) => {
            player.addEffect('regeneration', 2 * TicksPerSecond, { amplifier: 1 });
            player.addEffect('fire_resistance', 2 * TicksPerSecond, { amplifier: 1 });
            player.addEffect('resistance', 2 * TicksPerSecond, { amplifier: 1 });
        }
    ],
    [
        'twb_farm:peanut_butter_item',
        (player) => {
            player.addEffect('slowness', 15 * TicksPerSecond, { amplifier: 1 });
            player.addEffect('strength', 15 * TicksPerSecond, { amplifier: 1 });
        }
    ],
]);
