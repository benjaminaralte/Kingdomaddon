import { EquipmentSlot, ItemStack, world } from '@minecraft/server';
import ScriptingModule from '../scriptingModule';
import { addItemToInventory, getItemInSlot, translate } from '../util/utils';
import FormController from './formController';
import IS_ADDON from '../config';
// Register all wikis
import './wiki/rootWiki';
import './wiki/farming/root'; // [include] farming common_crop
import './wiki/animalWiki'; // [include] common_animal animals nature
export default class FormsModule extends ScriptingModule {
    constructor() {
        super('FormsModule');
    }
    onInitialize() {
        FormController.compileAll();
        world.afterEvents.playerSpawn.subscribe(() => {
            const players = world.getPlayers();
            for (const player of players) {
                // If player has already joined, do nothing.
                if (player.hasTag('twb_farm:has_joined'))
                    return;
                // Give scroll of knowledge to player.
                player.sendMessage(translate('info.twb_farm:scroll_of_knowledge'));
                addItemToInventory(player, new ItemStack('twb_farm:scroll_of_knowledge'));
                player.addTag('twb_farm:has_joined');
                // Give items depening on addon type.
                addItemToInventory(player, new ItemStack('twb_farm:farm_blueprint_item')); // [include] farming
            }
        });
        world.afterEvents.itemUse.subscribe((event) => {
            const player = event.source;
            const item = getItemInSlot(player, EquipmentSlot.Mainhand);
            if (item?.typeId === 'twb_farm:scroll_of_knowledge') {
                // Check if player has clicked on any entities
                const entitiesHit = player.getEntitiesFromViewDirection({ maxDistance: 6 });
                for (const hit of entitiesHit) {
                    // Check if entity has a dedicated page
                    const form = FormController.getInteractionForEntity(hit.entity.typeId);
                    if (form) {
                        FormController.showForm(form.id, player);
                        return;
                    }
                }
                // Check if player has clicked on a block
                const blockHit = player.getBlockFromViewDirection({ maxDistance: 6 });
                if (blockHit) {
                    // Check if block has a dedicated page
                    const form = FormController.getInteractionForBlock(blockHit.block.permutation);
                    if (form) {
                        FormController.showForm(form.id, player);
                        return;
                    }
                }
                // Show main form
                this.showMainForm(player);
            }
        });
        this.addScriptEvent('twb_farm:log_form_lang_keys', () => {
            const keys = [];
            const parse = (text) => {
                if (text?.translate)
                    keys.push(text.translate);
                else if (text?.rawtext)
                    text.rawtext.forEach(parse);
            };
            FormController.getAll().forEach((form) => {
                parse(form.getTitle());
                parse(form.getBody());
                form.getButtons()
                    .filter((button) => typeof button.text !== 'string')
                    .forEach((button) => parse(button.text));
            });
            console.warn([...new Set(keys)].join('\n'));
        });
    }
    showMainForm(player) {
        let form;
        if (IS_ADDON) {
            form = FormController.get('farm_root'); // [include] farming
        }
        if (!form)
            form = FormController.getRootForm();
        FormController.showForm(form.id, player);
    }
}
