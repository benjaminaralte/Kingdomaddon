/* eslint-disable no-new */
import MenuForm from '../types/menuForm';
new MenuForm('root', {
    hasBody: true,
    references: 'root',
    noBackButton: true,
});
