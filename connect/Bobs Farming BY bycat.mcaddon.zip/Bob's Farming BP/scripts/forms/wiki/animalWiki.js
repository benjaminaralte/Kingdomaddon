import MenuForm from '../types/menuForm';
new MenuForm('animals_menu_items', {
    references: 'animals_items',
    tags: ['items'],
    iconPath: 'textures/twb/farm/forms/icons/animals',
});
