/* eslint-disable no-new */
import MenuForm from '../../types/menuForm';
import ItemForm from '../../types/itemForm';
new MenuForm('farm_vehicles_menu', {
    hasBody: true,
    references: 'farm_vehicles_menu',
    tags: ['farm_root'],
    iconPath: 'textures/twb/farm/forms/icons/vehicles',
});
// Farm Vehicles Menu
// [include] farm_vehicles farming ...
new ItemForm('farm_blueprint_item', {
    tags: ['farm_vehicles_menu', 'bedformer', 'planter', 'fertilizer', 'harvester', 'tractor', 'quad', 'dirt_bike', 'bob_farmer'],
    references: 'farm_blueprint',
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/blueprint',
});
// ...
// [include] quad farming ...
new ItemForm('quad', {
    title: { translate: 'entity.twb_farm:quad.name' },
    tags: ['farm_vehicles_menu'],
    references: 'quad',
    hasRecipe: true,
    iconPath: 'textures/twb/farm/forms/icons/vehicles/quad',
    interact: {
        entities: ['twb_farm:quad']
    },
});
// ...
// [include] dirt_bike farming ...
new ItemForm('dirt_bike', {
    title: { translate: 'entity.twb_farm:dirt_bike.name' },
    tags: ['farm_vehicles_menu'],
    references: 'dirt_bike',
    hasRecipe: true,
    iconPath: 'textures/twb/farm/forms/icons/vehicles/dirt_bike',
    interact: {
        entities: ['twb_farm:dirt_bike']
    },
});
// ...
// [include] tractor farming ...
new ItemForm('tractor', {
    title: { translate: 'entity.twb_farm:tractor.name' },
    tags: [
        'farm_vehicles_menu',
        'farm_farming_tutorial',
        'bedformer',
        'planter',
        'fertilizer',
        'harvester',
    ],
    references: 'tractor',
    hasRecipe: true,
    iconPath: 'textures/twb/farm/forms/icons/vehicles/tractor',
    interact: {
        entities: ['twb_farm:tractor']
    },
});
new ItemForm('tractor_bedformer_item', {
    title: { translate: 'tile.twb_farm:tractor_bedformer_item.name' },
    tags: ['farm_vehicles_menu', 'tractor'],
    references: 'bedformer',
    hasRecipe: true,
    iconPath: 'textures/twb/farm/forms/icons/vehicles/tractor_bedformer',
});
new ItemForm('tractor_planter_item', {
    title: { translate: 'tile.twb_farm:tractor_planter_item.name' },
    tags: ['farm_vehicles_menu', 'tractor'],
    references: 'planter',
    hasRecipe: true,
    iconPath: 'textures/twb/farm/forms/icons/vehicles/tractor_planter',
});
new ItemForm('tractor_fertilizer_item', {
    title: { translate: 'tile.twb_farm:tractor_fertilizer_item.name' },
    tags: ['farm_vehicles_menu', 'tractor'],
    references: 'fertilizer',
    hasRecipe: true,
    iconPath: 'textures/twb/farm/forms/icons/vehicles/tractor_fertilizer',
});
new ItemForm('tractor_harvester_item', {
    title: { translate: 'tile.twb_farm:tractor_harvester_item.name' },
    tags: ['farm_vehicles_menu', 'tractor'],
    references: 'harvester',
    hasRecipe: true,
    iconPath: 'textures/twb/farm/forms/icons/vehicles/tractor_harvester',
});
// ...
