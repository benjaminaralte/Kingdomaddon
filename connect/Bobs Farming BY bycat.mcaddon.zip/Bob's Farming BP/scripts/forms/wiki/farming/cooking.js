/* eslint-disable no-new */
import MenuForm from '../../types/menuForm';
import ItemForm from '../../types/itemForm';
new MenuForm('farm_cooking_menu', {
    hasBody: true,
    references: 'farm_cooking_menu',
    tags: ['farm_root'],
    iconPath: 'textures/twb/farm/forms/icons/cooking',
});
// Farm Cooking Menu
new ItemForm('farm_cooking_tutorial', {
    references: 'farm_cooking_tutorial',
    descriptionSections: 5,
    tags: ['farm_cooking_menu', 'cooking_pot'],
    iconPath: 'textures/twb/farm/forms/icons/tutorial',
});
// [include] cooking_pot farming ...
new ItemForm('beef_stew', {
    references: 'beef_stew_item',
    tags: ['farm_cooking_menu', 'cooking_pot', 'onion_item'],
    isCookable: true,
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/beef_stew',
});
// ...
// [include] cooking_pot farming ...
new ItemForm('chicken_stew', {
    references: 'chicken_stew_item',
    tags: ['farm_cooking_menu', 'cooking_pot', 'garlic_item', 'leek_item'],
    isCookable: true,
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/chicken_stew',
});
// ...
// [include] rice_cooked farming ...
new ItemForm('rice_cooked_item', {
    references: 'rice_cooked_item',
    tags: ['farm_cooking_menu', 'cooking_pot', 'rice_item'],
    isCookable: true,
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/rice_cooked',
});
// ...
// [include] chicken_delight farming ...
new ItemForm('chicken_delight_item', {
    references: 'chicken_delight_item',
    tags: ['farm_cooking_menu', 'onion_item', 'garlic_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/chicken_delight',
});
// ...
// [include] jar farming ...
new ItemForm('jar_item', {
    references: 'jar_item',
    tags: ['farm_cooking_menu', 'farm_cooking_tutorial'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/jar',
});
// ...
// [include] jar_water farming ...
new ItemForm('jar_water_item', {
    references: 'jar_water_item',
    tags: ['farm_cooking_menu', 'jar_item', 'farm_cooking_tutorial'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/jar_water',
});
// ...
// [include] tomato farming ...
new ItemForm('tomato_sauce_item', {
    references: 'tomato_sauce_item',
    tags: ['farm_cooking_menu', 'tomato_item', 'jar_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/tomato.sauce',
});
// ...
// [include] strawberry farming ...
new ItemForm('strawberry_jam_item', {
    references: 'strawberry_jam_item',
    tags: ['farm_cooking_menu', 'strawberry_item', 'jar_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/strawberry.jam',
});
// ...
// [include] fruit_smoothie farming ...
new ItemForm('fruit_smoothie_item', {
    references: 'fruit_smoothie_item',
    tags: ['farm_cooking_menu', 'strawberry_item', 'banana_item', 'pineapple_item', 'grape_item', 'jar_water_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/fruit_smoothie',
});
// ...
// [include] green_smoothie farming ...
new ItemForm('green_smoothie_item', {
    references: 'green_smoothie_item',
    tags: ['farm_cooking_menu', 'spinach_item', 'broccoli_item', 'leek_item', 'jar_water_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/green_smoothie',
});
// ...
// [include] peanut farming ...
new ItemForm('peanut_butter_item', {
    references: 'peanut_butter_item',
    tags: ['farm_cooking_menu', 'peanut_item', 'jar_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/peanut.butter',
});
// ...
// [include] pbj_sandwich farming ...
new ItemForm('pbj_sandwich_item', {
    references: 'pbj_sandwich_item',
    tags: ['farm_cooking_menu', 'beanput_butter_item', 'strawberry_jam_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/pbj_sandwich',
});
// ...
// [include] corn farming ...
new ItemForm('corn_cob_item', {
    references: 'corn_cob_item',
    tags: ['farm_cooking_menu', 'corn_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/corn.cob',
});
// ...
// [include] cheese farming ...
new ItemForm('cheese_bucket_item', {
    references: 'cheese_bucket_item',
    tags: ['farm_cooking_menu'],
    byFurnace: true,
    iconPath: 'textures/twb/farm/crops/items/cheese.bucket',
});
new ItemForm('cheese_item', {
    references: 'cheese_item',
    tags: ['farm_cooking_menu', 'cheese_bucket_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/cheese',
});
// ...
// [include] garlic farming ...
new ItemForm('garlic_bread_item', {
    references: 'garlic_bread_item',
    tags: ['farm_cooking_menu', 'garlic_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/garlic.bread',
});
// ...
// [include] hamburger farming ...
new ItemForm('hamburger_item', {
    references: 'hamburger_item',
    tags: ['farm_cooking_menu', 'cheese_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/hamburger',
});
// ...
// [include] strawberry farming ...
new ItemForm('pancakes_item', {
    references: 'pancakes_item',
    tags: ['farm_cooking_menu', 'strawberry_jam_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/pancakes',
});
// ...
// [include] pizza farming ...
new ItemForm('pizza_item', {
    references: 'pizza_item',
    tags: ['farm_cooking_menu', 'cheese_item', 'tomato_sauce_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/pizza',
});
// ...
// [include] pineapple_pizza farming ...
new ItemForm('pineapple_pizza_item', {
    references: 'pineapple_pizza_item',
    tags: ['farm_cooking_menu', 'pineapple_item', 'pizza_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/pineapple_pizza',
});
// ...
// [include] rice_cooked farming ...
new ItemForm('sushi_item', {
    references: 'sushi_item',
    tags: ['farm_cooking_menu', 'cooked_rice_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/sushi',
});
// ...
// [include] broccoli farming ...
new ItemForm('broccoli_roasted_item', {
    references: 'broccoli_roasted_item',
    tags: ['farm_cooking_menu', 'broccoli_item'],
    byFurnace: true,
    iconPath: 'textures/twb/farm/crops/items/broccoli.roasted',
});
// ...
// [include] cauliflower farming ...
new ItemForm('cauliflower_roasted_item', {
    references: 'cauliflower_roasted_item',
    tags: ['farm_cooking_menu', 'cauliflower_item'],
    byFurnace: true,
    iconPath: 'textures/twb/farm/crops/items/cauliflower.roasted',
});
// ...
// [include] eggplant farming ...
new ItemForm('eggplant_roasted_item', {
    references: 'eggplant_roasted_item',
    tags: ['farm_cooking_menu', 'eggplant_item'],
    byFurnace: true,
    iconPath: 'textures/twb/farm/crops/items/eggplant.roasted',
});
// ...
// [include] fried_rice farming ...
new ItemForm('fried_rice_item', {
    references: 'fried_rice_item',
    tags: ['farm_cooking_menu', 'leek_item', 'cooked_rice_item', 'chili_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/fried_rice',
});
// ...
// [include] ratatouille farming ...
new ItemForm('ratatouille_item', {
    references: 'ratatouille_item',
    tags: ['farm_cooking_menu', 'onion_item', 'chili_item', 'roasted_eggplant_item', 'tomato_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/ratatouille',
});
// ...
