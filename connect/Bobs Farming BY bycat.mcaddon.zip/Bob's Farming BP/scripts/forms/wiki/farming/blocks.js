/* eslint-disable no-new */
import MenuForm from '../../types/menuForm';
import ItemForm from '../../types/itemForm';
new MenuForm('farm_blocks_menu', {
    hasBody: true,
    references: 'farm_blocks_menu',
    tags: ['farm_root'],
    iconPath: 'textures/twb/farm/forms/icons/blocks',
});
// Farm Blocks Menu
// [include] cooking_pot farming ...
new ItemForm('cooking_pot_item', {
    references: 'cooking_pot',
    tags: [
        'farm_blocks_menu',
        'beef_stew_item',
        'chicken_stew_item',
        'rice_cooked_item',
        'farm_cooking_tutorial',
    ],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/cooking_pot',
    interact: {
        blocks: ['twb_farm:cooking_pot']
    }
});
// ...
