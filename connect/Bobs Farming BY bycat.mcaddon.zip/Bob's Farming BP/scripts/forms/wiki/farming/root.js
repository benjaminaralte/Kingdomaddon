/* eslint-disable no-new */
import MenuForm from '../../types/menuForm';
import './farming';
import './cooking';
import './vehicles';
import './blocks';
import './mobs';
// [include] farming common_crop ...
new MenuForm('farm_root', {
    hasBody: true,
    references: 'farm_root',
    tags: ['root'],
    iconPath: 'textures/items/wheat',
    noBackButton: true
});
// ...
