/* eslint-disable no-new */
import MenuForm from '../../types/menuForm';
import ItemForm, { Behavior } from '../../types/itemForm';
new MenuForm('farm_mobs_menu', {
    hasBody: true,
    references: 'farm_mobs_menu',
    tags: ['farm_root'],
    iconPath: 'textures/twb/farm/forms/icons/mobs',
});
// Farm Mobs Menu
new ItemForm('chirping_bird', {
    title: { translate: 'entity.twb_farm:chirping_bird.name' },
    iconPath: 'textures/twb/farm/forms/icons/animals/chirping_bird',
    tags: [
        'farm_mobs_menu',
        'farm_farming_tutorial',
    ],
    isBreedable: false,
    isTameable: false,
    behavior: Behavior.FRIENDLY,
    biomes: ['forest'],
    drops: ['twb_farm.forms.chirping_bird.drops'],
    food: ['item.wheat_seeds.name'],
    interact: {
        entities: ['twb_farm:chirping_bird'],
    },
});
new ItemForm('bob_farmer', {
    title: { translate: 'entity.twb_farm:bob_farmer.name' },
    tags: [
        'farm_mobs_menu',
        'farm_farming_tutorial',
        'farm_blueprint',
    ],
    references: 'bob_farmer',
    iconPath: 'textures/twb/farm/forms/icons/npcs/bob_farmer',
    biomes: ['overworld'],
    behavior: Behavior.FRIENDLY,
    interact: {
        entities: ['twb_farm:bob_farmer'],
    },
});
