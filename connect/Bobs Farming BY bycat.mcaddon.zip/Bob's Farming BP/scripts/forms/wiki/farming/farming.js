/* eslint-disable no-new */
import MenuForm from '../../types/menuForm';
import ItemForm from '../../types/itemForm';
new MenuForm('farm_farming_menu', {
    hasBody: true,
    references: 'farm_farming_menu',
    tags: ['farm_root'],
    iconPath: 'textures/twb/farm/forms/icons/farming',
});
// Farm Farming Menu
new ItemForm('farm_farming_tutorial', {
    references: 'farm_farming_tutorial',
    descriptionSections: 5,
    tags: ['farm_farming_menu'],
    iconPath: 'textures/twb/farm/forms/icons/tutorial',
});
new MenuForm('farm_seeds_menu', {
    hasBody: true,
    references: 'farm_seeds_menu',
    tags: [
        'farm_farming_menu',
        'farm_farming_tutorial',
    ],
    iconPath: 'textures/twb/farm/crops/items/corn.seeds',
});
new MenuForm('farm_crops_menu', {
    hasBody: true,
    references: 'farm_crops_menu',
    tags: ['farm_farming_menu'],
    iconPath: 'textures/twb/farm/crops/items/corn',
});
new MenuForm('farm_tools_menu', {
    hasBody: true,
    references: 'farm_tools_menu',
    tags: [
        'farm_farming_menu',
        'farm_farming_tutorial',
    ],
    iconPath: 'textures/twb/farm/crops/items/iron_scythe',
});
// Farm Crops Menu & Farm Seeds Menu
// [include] banana farming ...
new ItemForm('banana_seeds', {
    references: 'banana_seeds',
    tags: ['farm_seeds_menu', 'banana_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/banana.seeds',
    interact: {
        blocks: ['twb_farm:banana_bottom', 'twb_farm:banana_top']
    },
});
new ItemForm('banana_item', {
    references: 'banana_item',
    tags: [
        'farm_crops_menu',
        'banana_seeds',
    ],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/banana',
});
// ...
// [include] broccoli farming ...
new ItemForm('broccoli_seeds', {
    references: 'broccoli_seeds',
    tags: ['farm_seeds_menu', 'broccoli_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/broccoli.seeds',
    interact: {
        blocks: ['twb_farm:broccoli']
    },
});
new ItemForm('broccoli_item', {
    references: 'broccoli_item',
    tags: ['farm_crops_menu', 'broccoli_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/broccoli',
});
// ...
// [include] cabbage farming ...
new ItemForm('cabbage_seeds', {
    references: 'cabbage_seeds',
    tags: ['farm_seeds_menu', 'cabbage_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/cabbage.seeds',
    interact: {
        blocks: ['twb_farm:cabbage']
    },
});
new ItemForm('cabbage_item', {
    references: 'cabbage_item',
    tags: ['farm_crops_menu', 'cabbage_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/cabbage',
});
// ...
// [include] cauliflower farming ...
new ItemForm('cauliflower_seeds', {
    references: 'cauliflower_seeds',
    tags: ['farm_seeds_menu', 'cauliflower_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/cauliflower.seeds',
    interact: {
        blocks: ['twb_farm:cauliflower']
    },
});
new ItemForm('cauliflower_item', {
    references: 'cauliflower_item',
    tags: ['farm_crops_menu', 'cauliflower_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/cauliflower',
});
// ...
// [include] chili farming ...
new ItemForm('chili_seeds', {
    references: 'chili_seeds',
    tags: ['farm_seeds_menu', 'chili_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/chili.seeds',
    interact: {
        blocks: ['twb_farm:chili']
    },
});
new ItemForm('chili_item', {
    references: 'chili_item',
    tags: ['farm_crops_menu', 'chili_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/chili',
});
// ...
// [include] corn farming ...
new ItemForm('corn_seeds', {
    references: 'corn_seeds',
    tags: ['farm_seeds_menu', 'corn_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/corn.seeds',
    interact: {
        blocks: ['twb_farm:corn_bottom', 'twb_farm:corn_top']
    },
});
new ItemForm('corn_item', {
    references: 'corn_item',
    tags: ['farm_crops_menu', 'corn_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/corn',
});
// ...
// [include] eggplant farming ...
new ItemForm('eggplant_seeds', {
    references: 'eggplant_seeds',
    tags: ['farm_seeds_menu', 'eggplant_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/eggplant.seeds',
    interact: {
        blocks: ['twb_farm:eggplant']
    },
});
new ItemForm('eggplant_item', {
    references: 'eggplant_item',
    tags: ['farm_crops_menu', 'eggplant_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/eggplant',
});
// ...
// [include] garlic farming ...
new ItemForm('garlic_item', {
    references: 'garlic_item',
    tags: ['farm_crops_menu'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/garlic',
    interact: {
        blocks: ['twb_farm:garlic']
    },
});
// ...
// [include] grape farming ...
new ItemForm('grape_seeds', {
    references: 'grape_seeds',
    tags: ['farm_seeds_menu', 'grape_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/grape.seeds',
    interact: {
        blocks: ['twb_farm:grape']
    },
});
new ItemForm('grape_item', {
    references: 'grape_item',
    tags: ['farm_crops_menu', 'grape_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/grape',
});
// ...
// [include] leek farming ...
new ItemForm('leek_item', {
    references: 'leek_item',
    tags: ['farm_crops_menu'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/leek',
    interact: {
        blocks: ['twb_farm:leek']
    },
});
// ...
// [include] onion farming ...
new ItemForm('onion_item', {
    references: 'onion_item',
    tags: [
        'farm_crops_menu',
        'beef_stew_item',
        'chicken_delight_item',
        'ratatouille_item',
    ],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/onion',
    interact: {
        blocks: ['twb_farm:onion']
    },
});
// ...
// [include] peanut farming ...
new ItemForm('peanut_item', {
    references: 'peanut_item',
    tags: [
        'farm_crops_menu',
    ],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/peanut',
    interact: {
        blocks: ['twb_farm:peanut']
    },
});
// ...
// [include] pineapple farming ...
new ItemForm('pineapple_seeds', {
    references: 'pineapple_seeds',
    tags: ['farm_seeds_menu', 'pineapple_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/pineapple.seeds',
    interact: {
        blocks: ['twb_farm:pineapple_plant']
    },
});
new ItemForm('pineapple_item', {
    references: 'pineapple_item',
    tags: ['farm_crops_menu', 'pineapple_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/pineapple',
    interact: {
        blocks: ['twb_farm:pineapple']
    }
});
// ...
// [include] rice farming ...
new ItemForm('rice_item', {
    references: 'rice_item',
    tags: ['farm_crops_menu'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/rice',
    interact: {
        blocks: ['twb_farm:rice']
    }
});
// ...
// [include] spinach farming ...
new ItemForm('spinach_seeds', {
    references: 'spinach_seeds',
    tags: ['farm_seeds_menu', 'spinach_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/spinach.seeds',
    interact: {
        blocks: ['twb_farm:spinach']
    },
});
new ItemForm('spinach_item', {
    references: 'spinach_item',
    tags: ['farm_crops_menu', 'spinach_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/spinach',
});
// ...
// [include] strawberry farming ...
new ItemForm('strawberry_seeds', {
    references: 'strawberry_seeds',
    tags: ['farm_seeds_menu', 'strawberry_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/strawberry.seeds',
    interact: {
        blocks: ['twb_farm:strawberry']
    },
});
new ItemForm('strawberry_item', {
    references: 'strawberry_item',
    tags: ['farm_crops_menu', 'strawberry_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/strawberry',
});
// ...
// [include] tomato farming ...
new ItemForm('tomato_seeds', {
    references: 'tomato_seeds',
    tags: ['farm_seeds_menu', 'tomato_item'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/tomato.seeds',
    interact: {
        blocks: ['twb_farm:tomato']
    },
});
new ItemForm('tomato_item', {
    references: 'tomato_item',
    tags: ['farm_crops_menu', 'tomato_seeds'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/tomato',
});
// ...
// Farm Tools Menu
// [include] watering_can farming ...
new ItemForm('watering_can_empty_item', {
    tags: ['farm_tools_menu'],
    references: 'watering_can',
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/watering_can_empty',
});
new ItemForm('watering_can_item', {
    references: 'watering_can_compost',
    tags: ['farm_tools_menu', 'watering_can'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/watering_can',
});
new ItemForm('watering_can_compost_item', {
    references: 'watering_can',
    tags: ['farm_tools_menu', 'watering_can_compost'],
    hasRecipe: false,
    iconPath: 'textures/twb/farm/crops/items/watering_can_compost',
});
// ...
// [include] scythe farming ...
new ItemForm('wooden_scythe', {
    tags: ['farm_tools_menu'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/wooden_scythe',
});
new ItemForm('stone_scythe', {
    tags: ['farm_tools_menu'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/stone_scythe',
});
new ItemForm('iron_scythe', {
    tags: ['farm_tools_menu'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/iron_scythe',
});
new ItemForm('golden_scythe', {
    tags: ['farm_tools_menu'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/golden_scythe',
});
new ItemForm('diamond_scythe', {
    tags: ['farm_tools_menu'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/diamond_scythe',
});
new ItemForm('netherite_scythe', {
    tags: ['farm_tools_menu'],
    hasRecipe: true,
    iconPath: 'textures/twb/farm/crops/items/netherite_scythe',
});
// ...
