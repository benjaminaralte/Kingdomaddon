import { ActionFormData } from '@minecraft/server-ui';
// eslint-disable-next-line import/no-cycle
import FormController from './formController';
import { translate } from '../util/utils';
export var FormButtonType;
(function (FormButtonType) {
    FormButtonType[FormButtonType["OPEN"] = 0] = "OPEN";
    FormButtonType[FormButtonType["BACK"] = 1] = "BACK";
    FormButtonType[FormButtonType["CUSTOM"] = 2] = "CUSTOM";
})(FormButtonType || (FormButtonType = {}));
export class Form {
    constructor(id, options = {}) {
        this.id = id;
        this.options = options;
        this.buttons = [];
        FormController.add(this);
    }
    toString() {
        return `Form[id=${this.id}]`;
    }
    getTitle() {
        return this.title || { text: 'Unknown' };
    }
    getBody() {
        return this.body;
    }
    getButtons() {
        return this.buttons;
    }
    /**
     * Set the title of this form.
     * @param title A translation key or RawMessage
     * @returns The form
     */
    setTitle(title) {
        if (typeof title === 'string') {
            this.title = { translate: title };
        }
        else {
            this.title = title;
        }
        return this;
    }
    /**
     * Set the title of this form.
     * @param body A translation key or RawMessage
     * @returns The form
     */
    setBody(body) {
        if (typeof body === 'string') {
            this.body = { translate: body };
        }
        else {
            this.body = body;
        }
        return this;
    }
    /**
     * Add a button to this form.
     * @param button A button
     * @returns The form
     */
    addButton(button) {
        this.buttons.push(button);
        return this;
    }
    /**
     * Add a "Back" button to this form.
     * @returns The form
     */
    addBackButton() {
        this.buttons.push({
            text: translate('twb_farm.forms.general.back'),
            buttonType: FormButtonType.BACK,
        });
        return this;
    }
    build() {
        const form = new ActionFormData();
        if (this.title)
            form.title(this.title);
        if (this.body)
            form.body(this.body);
        this.buttons.forEach((b) => form.button(b.text, b.iconPath));
        return form;
    }
    /**
     * Retrieve the IDs of all Forms that can be opened through
     * this form (excluding the "Back" button).
     * @returns A list of Form IDs
     */
    getReferencedFormIDs() {
        return this.buttons
            .filter((b) => b.buttonType === FormButtonType.OPEN)
            .map((b) => b.openForm);
    }
    /**
     * Hook for whenever a player submits a response to this Form.
     * @param player The player responding
     * @param response The response
     */
    onResponse(player, response) {
        if (!response.canceled) {
            const button = this.buttons[response.selection];
            this.onButtonPressed(player, button);
        }
    }
    onButtonPressed(player, button) {
        switch (button.buttonType) {
            case FormButtonType.OPEN:
                FormController.showForm(button.openForm, player);
                button.callback?.(player);
                break;
            case FormButtonType.BACK:
                FormController.showPrevious(player, this);
                button.callback?.(player);
                break;
            case FormButtonType.CUSTOM:
                button.callback?.(player);
                break;
            default:
                break;
        }
    }
}
export class CompilableForm {
    constructor(id, options) {
        this.id = id;
        this.options = options;
        FormController.add(this);
    }
    toString() {
        return `CompilableForm[id=${this.id}]`;
    }
}
