/* eslint-disable max-classes-per-file */
import { BlockPermutation } from '@minecraft/server';
// eslint-disable-next-line import/no-cycle
import { Form } from './formData';
let rootFormId = 'root';
rootFormId = 'farm_root'; // [include] farming
/**
 * Form management system. Used to efficiently collect forms and create
 * indices for them. Responsible for handling button presses.
 * Use `FormController.showForm()` to show a form to a player.
 */
export default class FormController {
    static has(id) {
        return FormController.forms.has(id);
    }
    static get(id) {
        const form = FormController.forms.get(id);
        // Return if form does not exist or was already compiled
        if (!form || form instanceof Form)
            return form;
        // Otherwise compile first
        return this.compile(form);
    }
    static getAll() {
        return Array(...FormController.forms.keys())
            .map((id) => FormController.get(id));
    }
    /**
     * Add a new form to the library
     * @param form The form to add
     */
    static add(form) {
        if (FormController.forms.has(form.id)) {
            throw new Error(`Definition for ${form.id} already exists`);
        }
        // Register form
        FormController.forms.set(form.id, form);
        // Register tags
        form.options.tags?.forEach((tag) => {
            const tagged = FormController.tags.get(tag) || new Set();
            tagged.add(form.id);
            FormController.tags.set(tag, tagged);
        });
        // Register interactions
        form.options.interact?.blocks?.forEach((block) => {
            if (block instanceof BlockPermutation) {
                this.interactPermutations.set(block, form.id);
            }
            else {
                this.interactBlocks.set(block, form.id);
            }
        });
        form.options.interact?.entities?.forEach((entity) => {
            this.interactEntities.set(entity, form.id);
        });
        if (form instanceof Form) {
            this.registerReferences(form);
        }
    }
    static compileAll() {
        let numCompiled = 0;
        // Lazy iterator, important due to recursive compilations
        for (const form of FormController.forms.values()) {
            // Make sure it wasn't compiled yet
            if (!(form instanceof Form)) {
                this.compile(form);
                numCompiled++;
            }
        }
        console.log('Compiled', numCompiled, 'forms');
    }
    static compile(form) {
        const existing = FormController.forms.get(form.id);
        if (existing && existing !== form) {
            throw new Error(`Cannot compile ${form} because of conflicts with ${existing}`);
        }
        try {
            // First remove the form to avoid conflicts when adding the compiled form
            if (existing)
                this.forms.delete(existing.id);
            // Compile the form
            const compiled = form.compile();
            return compiled;
        }
        catch (e) {
            // Readd uncompiled form in case of an error
            if (existing)
                this.forms.set(existing.id, existing);
            throw e;
        }
    }
    static registerReferences(form) {
        form.getReferencedFormIDs().forEach((id) => {
            const refs = FormController.references.get(id) || new Set();
            refs.add(form.id);
            FormController.references.set(id, refs);
        });
    }
    /**
     * Retrieve an array of forms with a specific tag
     * @param tag A tag to search for
     * @returns All forms with the provided tag
     */
    static withTag(tag) {
        const tagged = FormController.tags.get(tag);
        if (!tagged)
            return [];
        const res = [];
        tagged.forEach((id) => res.push(FormController.forms.get(id)));
        return res;
    }
    /**
     * Show a form to a player.
     * @param id The ID of the form to show
     * @param player The player to show the form to
     * @param self Optionally, the form calling this request
     */
    static showForm(id, player) {
        // Retrieve form
        const form = FormController.get(id);
        if (!form)
            return;
        // Create form data and show to player
        const built = form.build();
        built.show(player).then((resp) => form.onResponse?.(player, resp));
        console.log('Showing', form, 'to', player.name);
        let path = FormController.paths.get(player) || [];
        if (path.length > 0 && !path[path.length - 1].getReferencedFormIDs().includes(form.id)) {
            // Reset path because previous form does not reference the current
            // form in any way; Most certainly the player closed and reopened
            // the wiki.
            path = [form];
        }
        else {
            // Add form to path of visited forms
            path.push(form);
        }
        FormController.paths.set(player, path);
    }
    static showPrevious(player, current) {
        // Remove current form from path
        let path = FormController.paths.get(player) || [];
        path.pop();
        // Create new path if empty
        if (!path.length) {
            path = FormController.getShortestPath(current);
        }
        // Retrieve new head of path
        const form = path[path.length - 1];
        // Create form data and show form to player
        const built = form.build();
        built.show(player).then((resp) => form.onResponse?.(player, resp));
        // Store new path
        FormController.paths.set(player, path);
    }
    static getRootForm() {
        const form = FormController.get(this.ROOT_FORM_ID);
        if (!form)
            throw new Error('No root form defined');
        return form;
    }
    /**
     * Find a path from the root form to the destination form consisting of the
     * least amount of steps.
     * @param dest The form to find a path to
     * @returns An array of forms, excluding the destination
     */
    static getShortestPath(dest) {
        const distances = {};
        const paths = {};
        const visited = new Set();
        // Get all the nodes of the graph
        const forms = Object.values(FormController.forms);
        const rootForm = this.getRootForm();
        if (dest === rootForm)
            return [rootForm];
        // Initially, set the shortest distance to every node as Infinity
        for (const form of forms) {
            distances[form.id] = Infinity;
            paths[form.id] = [];
        }
        // The distance from the start node to itself is 0
        distances[rootForm.id] = 0;
        // Loop until all nodes are visited
        while (forms.length) {
            // Sort nodes by distance and pick the closest unvisited node
            forms.sort((a, b) => distances[a.id] - distances[b.id]);
            const closestNode = forms.shift();
            // If the shortest distance to the closest node is still Infinity, then
            // remaining nodes are unreachable and we can break
            if (distances[closestNode.id] === Infinity)
                break;
            // Mark the chosen node as visited
            visited.add(closestNode.id);
            // For each neighboring node of the current node
            for (const neighborId of closestNode.getReferencedFormIDs()) {
                // Since all "paths" are of equal distance, once we
                // find the destination we can return immediately
                if (neighborId === dest.id) {
                    return paths[neighborId];
                }
                // If the neighbor hasn't been visited yet
                if (!visited.has(neighborId)) {
                    // Calculate tentative distance to the neighboring node
                    const newDistance = distances[closestNode.id] + 1;
                    const newPath = paths[closestNode.id].concat(closestNode);
                    // If the newly calculated distance is shorter than the
                    // previously known distance to this neighbor
                    if (newDistance < distances[neighborId]) {
                        // Update the shortest distance to this neighbor
                        distances[neighborId] = newDistance;
                        paths[neighborId] = newPath;
                    }
                }
            }
        }
        // We didn't find the node, just return to root
        return [rootForm];
    }
    static getInteractionForBlock(block) {
        // First check if we have this exact permutation hashed
        const formId1 = FormController.interactPermutations.get(block);
        if (formId1)
            return FormController.get(formId1);
        // Otherwise iterate over type IDs and see if they match the block
        for (const [typeId, formId2] of FormController.interactBlocks.entries()) {
            if (block.matches(typeId))
                return FormController.get(formId2);
        }
        return undefined;
    }
    static getInteractionForEntity(entity) {
        const formId = FormController.interactEntities.get(entity);
        if (formId)
            return FormController.get(formId);
        return undefined;
    }
}
FormController.ROOT_FORM_ID = rootFormId;
FormController.forms = new Map();
FormController.tags = new Map();
FormController.references = new Map();
FormController.paths = new Map();
// If a permutation has no blockstates we can use a map
// to look it up much more efficiently than by looping
FormController.interactPermutations = new Map();
FormController.interactBlocks = new Map();
FormController.interactEntities = new Map();
