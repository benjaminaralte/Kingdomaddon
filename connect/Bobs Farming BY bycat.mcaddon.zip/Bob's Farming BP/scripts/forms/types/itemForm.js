import { Form, FormButtonType } from '../formData';
import { translate } from '../../util/utils';
import FormController from '../formController';
export var Behavior;
(function (Behavior) {
    Behavior["FRIENDLY"] = "friendly";
    Behavior["NEUTRAL"] = "neutral";
    Behavior["HOSTILE"] = "hostile";
})(Behavior || (Behavior = {}));
/**
 * Form to efficiently show a bunch of information about an
 * item, block, or entity in a consistent format.
 */
export default class ItemForm {
    constructor(id, options = {}) {
        this.id = id;
        this.options = options;
        FormController.add(this);
    }
    toString() {
        return `ItemForm[id=${this.id}]`;
    }
    getTitle() {
        return this.options.title || translate(`item.twb_farm:${this.id}`);
    }
    compile() {
        const form = new Form(this.id, this.options);
        form.setTitle(this.getTitle());
        const newlines = { text: '\n\n' };
        const body = [];
        if (this.options.descriptionSections === undefined) {
            body.push(newlines, { translate: `twb_farm.forms.${this.id}.description` });
        }
        else if (this.options.descriptionSections > 0) {
            for (let section = 0; section < this.options.descriptionSections; section++) {
                body.push(newlines, { translate: `twb_farm.forms.${this.id}.description.${section}` });
            }
        }
        if (this.options.biomes !== undefined) {
            if (this.options.biomes.length === 0) {
                body.push(newlines, { translate: 'twb_farm.forms.general.no_biomes' });
            }
            else {
                body.push(newlines, { translate: 'twb_farm.forms.general.biomes' }, { text: ' ' });
                for (const biome of this.options.biomes) {
                    body.push({ translate: `twb_farm.forms.general.biome.${biome}` }, { text: ', ' });
                }
                body.pop(); // Remove trailing comma
            }
        }
        if (this.options.isBreedable === true) {
            body.push(newlines, { translate: 'twb_farm.forms.general.breedable' });
        }
        else if (this.options.isBreedable === false) {
            body.push(newlines, { translate: 'twb_farm.forms.general.not_breedable' });
        }
        if (this.options.isTameable === true) {
            body.push(newlines, { translate: 'twb_farm.forms.general.tameable' });
        }
        else if (this.options.isTameable === false) {
            body.push(newlines, { translate: 'twb_farm.forms.general.not_tameable' });
        }
        if (this.options.behavior !== undefined) {
            body.push(newlines, { translate: `twb_farm.forms.general.behavior.${this.options.behavior}` });
        }
        if (this.options.food !== undefined) {
            if (this.options.food.length === 0) {
                body.push(newlines, { translate: 'twb_farm.forms.general.no_food' });
            }
            else {
                body.push(newlines, { translate: 'twb_farm.forms.general.food' }, { text: ' ' });
                for (const item of this.options.food) {
                    body.push({ translate: `${item}` }, { text: ', ' });
                }
                body.pop(); // Remove trailing comma
            }
        }
        if (this.options.drops !== undefined) {
            if (this.options.drops.length === 0) {
                body.push(newlines, { translate: 'twb_farm.forms.general.no_drops' });
            }
            else {
                body.push(newlines, { translate: 'twb_farm.forms.general.drops' }, { text: ' ' });
                for (const drop of this.options.drops) {
                    body.push({ translate: drop }, { text: ', ' });
                }
                body.pop(); // Remove trailing comma
            }
        }
        if (this.options.isCookable === true) {
            body.push(newlines, { translate: 'twb_farm.forms.general.cookable' });
        }
        else if (this.options.isCookable === false) {
            body.push(newlines, { translate: 'twb_farm.forms.general.no_cookable' });
        }
        if (this.options.hasRecipe === true) {
            body.push(newlines, newlines, { translate: 'twb_farm.forms.general.crafting' }, newlines, { translate: 'twb_farm.forms.general.crafting_guide' });
        }
        else if (this.options.hasRecipe === false) {
            body.push(newlines, { translate: 'twb_farm.forms.general.no_crafting' });
        }
        if (this.options.isShearable === true) {
            body.push(newlines, { translate: 'twb_farm.forms.general.shearable' });
        }
        else if (this.options.isShearable === false) {
            body.push(newlines, { translate: 'twb_farm.forms.general.no_shearable' });
        }
        if (this.options.byFurnace === true) {
            body.push(newlines, { translate: 'twb_farm.forms.general.furnace' });
        }
        else if (this.options.byFurnace === false) {
            body.push(newlines, { translate: 'twb_farm.forms.general.no_furnace' });
        }
        body.push(newlines);
        form.setBody({ rawtext: body });
        if (this.options.references) {
            const taggedForms = FormController.withTag(this.options.references);
            for (const taggedForm of taggedForms) {
                form.addButton({
                    text: taggedForm.getTitle(),
                    iconPath: taggedForm.options.iconPath,
                    buttonType: FormButtonType.OPEN,
                    openForm: taggedForm.id
                });
            }
        }
        form.addBackButton();
        return form;
    }
}
