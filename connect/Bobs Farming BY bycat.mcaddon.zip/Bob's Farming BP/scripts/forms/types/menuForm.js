import { Form, FormButtonType } from '../formData';
import FormController from '../formController';
import { translate } from '../../util/utils';
/** Form to dynamically generate a number of buttons */
export default class MenuForm {
    constructor(id, options) {
        this.id = id;
        this.options = options;
        FormController.add(this);
    }
    toString() {
        return `MenuForm[id=${this.id}]`;
    }
    getTitle() {
        return this.options.title || translate(`twb_farm.forms.item.${this.id}`);
    }
    compile() {
        const form = new Form(this.id, this.options);
        form.setTitle(this.getTitle());
        const taggedForms = FormController.withTag(this.options.references);
        for (const taggedForm of taggedForms) {
            form.addButton({
                text: taggedForm.getTitle(),
                iconPath: taggedForm.options.iconPath,
                buttonType: FormButtonType.OPEN,
                openForm: taggedForm.id
            });
        }
        if (this.options.hasBody) {
            form.setBody({ rawtext: [{ text: '\n\n' }, translate(`twb_farm.forms.body.${this.id}`), { text: '\n\n' }] });
        }
        if (!this.options.noBackButton) {
            form.addBackButton();
        }
        return form;
    }
}
