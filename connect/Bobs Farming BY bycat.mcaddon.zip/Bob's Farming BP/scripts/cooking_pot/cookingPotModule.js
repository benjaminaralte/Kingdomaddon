import { BlockPermutation, system, world, ItemStack, Direction, EquipmentSlot } from '@minecraft/server';
import ScriptingModule from '../scriptingModule';
import { addItemToInventory, decreaseItemAmountInHand, getItemInSlot, setItemInSlot, sleep, translate } from '../util/utils';
var RecipeType;
(function (RecipeType) {
    RecipeType["NONE"] = "none";
    RecipeType["BASE"] = "base";
    RecipeType["CHICKEN"] = "minecraft:chicken";
    RecipeType["RICE"] = "twb_farm:rice_item";
    RecipeType["BEEF"] = "minecraft:beef";
    RecipeType["MUSHROOM"] = "minecraft:brown_mushroom";
    RecipeType["RABBIT"] = "minecraft:rabbit";
})(RecipeType || (RecipeType = {}));
export default class CookingPotModule extends ScriptingModule {
    constructor() {
        super('CookingPotModule');
        this.COOK_TIME_PREFIX = '\u0D9F';
        this.COOK_TIME_TICKS = 20 * 20;
        this.interactCooldown = new Set();
    }
    getCookTimePropertyKey(location) {
        return `${this.COOK_TIME_PREFIX}${location.x.toString(36)}_${location.y.toString(36)}_${location.z.toString(36)}`;
    }
    deregisterCookTime(location) {
        world.setDynamicProperty(this.getCookTimePropertyKey(location), undefined);
    }
    registerCookTime(location) {
        world.setDynamicProperty(this.getCookTimePropertyKey(location), system.currentTick);
    }
    hasFinishedCooking(location) {
        const key = this.getCookTimePropertyKey(location);
        const startTime = world.getDynamicProperty(key);
        // If we don't know the start time, just return true
        if (startTime === undefined)
            return true;
        const delta = system.currentTick - startTime;
        return delta > this.COOK_TIME_TICKS;
    }
    onInitialize() {
        // Tell players that pots need to be placed on top of campfires
        world.beforeEvents.itemUseOn.subscribe((event) => {
            if (event.itemStack.typeId === 'twb_farm:cooking_pot_item'
                && ((!event.block.permutation.matches('minecraft:campfire') && !event.block.permutation.matches('minecraft:soul_campfire')) || event.blockFace !== Direction.Up)) {
                const { source } = event;
                if (this.interactCooldown.has(source.name) || source.isSneaking)
                    return;
                this.interactCooldown.add(source.name);
                system.runTimeout(() => this.interactCooldown.delete(source.name), 5);
                source.sendMessage(translate('twb_farm.info.twb_farm:cooking_pot.placement'));
            }
        });
        // Replace Campfire with custom block to prevent smoke particles to spawn
        world.afterEvents.playerPlaceBlock.subscribe((event) => {
            const { block } = event;
            if (block.permutation.matches('twb_farm:cooking_pot')) {
                const below = block.below();
                if (!below)
                    return;
                const cardinals = ['north', 'east', 'south', 'west'];
                for (const cardinal of cardinals) {
                    if (below.permutation.getState('minecraft:cardinal_direction') === cardinal) {
                        if (below.permutation.matches('minecraft:campfire')) {
                            below.setPermutation(BlockPermutation.resolve('twb_farm:campfire', { 'minecraft:cardinal_direction': cardinal }));
                            break;
                        }
                        if (below.permutation.matches('minecraft:soul_campfire')) {
                            below.setPermutation(BlockPermutation.resolve('twb_farm:soul_campfire', { 'minecraft:cardinal_direction': cardinal }));
                            break;
                        }
                    }
                }
            }
        });
        // Replace custom block with Campfire after pot is destroyed
        world.afterEvents.playerBreakBlock.subscribe((event) => {
            if (event.brokenBlockPermutation.matches('twb_farm:cooking_pot')) {
                if (event.brokenBlockPermutation.getState('twb_farm:recipe_state') === 3) {
                    this.deregisterCookTime(event.block.location);
                }
                const below = event.block.below();
                if (!below)
                    return;
                const cardinals = ['north', 'east', 'south', 'west'];
                for (const cardinal of cardinals) {
                    if (below.permutation.matches('twb_farm:campfire', { 'minecraft:cardinal_direction': cardinal })) {
                        below.setPermutation(BlockPermutation.resolve('minecraft:campfire', { 'minecraft:cardinal_direction': cardinal }));
                        break;
                    }
                    if (below.permutation.matches('twb_farm:soul_campfire', { 'minecraft:cardinal_direction': cardinal })) {
                        below.setPermutation(BlockPermutation.resolve('minecraft:soul_campfire', { 'minecraft:cardinal_direction': cardinal }));
                        break;
                    }
                }
            }
        });
        // Handle block interactions
        world.afterEvents.itemUse.subscribe((event) => {
            const player = event.source;
            const block = player.getBlockFromViewDirection({
                includeLiquidBlocks: false,
                includePassableBlocks: true,
                maxDistance: 7,
            })?.block;
            if (!block)
                return;
            if (this.interactCooldown.has(player.name) || player.isSneaking)
                return;
            this.interactCooldown.add(player.name);
            system.runTimeout(() => this.interactCooldown.delete(player.name), 5);
            const item = event.itemStack;
            if (!item)
                return;
            if (block.permutation.matches('twb_farm:cooking_pot')) {
                const recipeType = block.permutation.getState('twb_farm:recipe_type');
                const recipeState = block.permutation.getState('twb_farm:recipe_state');
                if (!recipeType)
                    return;
                // Item to add to the player's inventory
                let newItem;
                if (item.typeId !== 'minecraft:bowl') {
                    // No bowl has been used; this covers all interactions with the cooking pot
                    // that are not about a bowl.
                    switch (recipeType) {
                        case RecipeType.NONE:
                            if (item?.typeId === 'twb_farm:jar_water_item') {
                                // Use Jar of water as a base for every stew brew
                                newItem = new ItemStack('twb_farm:jar_item');
                                world.playSound('cauldron.fillwater', block.location);
                                block.setPermutation(block.permutation.withState('twb_farm:recipe_type', 'base'));
                                block.setPermutation(block.permutation.withState('twb_farm:stew_level', 3));
                                break;
                            }
                            return;
                        case RecipeType.BASE: {
                            // Choose a base: Chicken, Beef, ...
                            const recipe = CookingPotModule.stewRecipes[item.typeId];
                            if (recipe) {
                                world.playSound('random.potion.brewed', block.location);
                                block.setPermutation(block.permutation.withState('twb_farm:recipe_type', item.typeId));
                                block.setPermutation(block.permutation.withState('twb_farm:recipe_state', 1));
                                break;
                            }
                            return;
                        }
                        // default for the recipes themselves; used to increase the recipe state.
                        default: {
                            const ingredients = CookingPotModule.stewRecipes[recipeType];
                            if (!ingredients)
                                return;
                            // If an ingredient is used, increment the recipe state
                            const ingredient = ingredients[recipeState - 1];
                            if (item.typeId === ingredient) {
                                world.playSound('random.potion.brewed', block.location);
                                block.setPermutation(block.permutation.withState('twb_farm:recipe_state', recipeState + 1));
                                if (recipeState === ingredients.length) {
                                    // The last ingredient was added so start cooking
                                    this.registerCookTime(block.location);
                                    this.spawnCookParticles(block, 20 * 19);
                                }
                                break;
                            }
                            return;
                        }
                    }
                }
                else {
                    // A bowl has been used! Trigger the bowl logic :)
                    // If the cooking pot is empty, let the player know
                    if (recipeType === RecipeType.NONE) {
                        player.sendMessage(translate('twb_farm.info.twb_farm:cooking_pot.empty'));
                        return;
                    }
                    // If the cooking pot is missing ingredients, let the player know
                    // eslint-disable-next-line max-len
                    if (recipeType === RecipeType.BASE || recipeState <= CookingPotModule.stewRecipes[recipeType].length) {
                        player.sendMessage(translate('twb_farm.info.twb_farm:cooking_pot.missing_ingredients'));
                        return;
                    }
                    // If the cooking pot has not yet finished cooking, let the player know
                    if (!this.hasFinishedCooking(block.location)) {
                        player.sendMessage(translate('twb_farm.info.twb_farm:cooking_pot.cooking'));
                        return;
                    }
                    // Give the player some stew! :)
                    world.playSound('mob.slime.attack', block.location);
                    const stewLevel = block.permutation.getState('twb_farm:stew_level');
                    let permutation = block.permutation.withState('twb_farm:stew_level', Math.max(stewLevel - 1, 0));
                    if (stewLevel === 1) {
                        permutation = permutation.withState('twb_farm:recipe_type', 'none').withState('twb_farm:recipe_state', 0);
                        this.deregisterCookTime(block.location);
                    }
                    block.setPermutation(permutation);
                    // Some exceptions of the new Item Logic
                    if (recipeType === 'minecraft:brown_mushroom') {
                        newItem = new ItemStack('minecraft:mushroom_stew');
                    }
                    else if (recipeType === 'minecraft:rabbit') {
                        newItem = new ItemStack('minecraft:rabbit_stew');
                    }
                    else if (recipeType === 'twb_farm:rice_item') {
                        newItem = new ItemStack('twb_farm:rice_cooked_item');
                    }
                    else {
                        newItem = new ItemStack(`twb_farm:${recipeType.split(':')[1].split('_')[0]}_stew`);
                    }
                }
                // At this point, we should always remove 1 item from the players main hand.
                decreaseItemAmountInHand(player, 1, true);
                // If 'newItem' is defined, it means that the player should obtain a new item, possibly
                // in their main hand.
                if (newItem) {
                    const hasMainHandItem = getItemInSlot(player, EquipmentSlot.Mainhand);
                    if (hasMainHandItem) {
                        addItemToInventory(player, newItem);
                    }
                    else {
                        setItemInSlot(player, EquipmentSlot.Mainhand, newItem);
                    }
                }
            }
        });
    }
    onSecond() {
        const blocks = new Set();
        world.getPlayers().forEach((player) => {
            const block = player.getBlockFromViewDirection({
                includeLiquidBlocks: true,
                includePassableBlocks: true,
                maxDistance: 7,
            })?.block;
            if (block?.permutation.matches('twb_farm:cooking_pot')) {
                blocks.add(block);
            }
        });
        blocks.forEach((block) => {
            const location = block.center();
            const recipeType = block.permutation.getState('twb_farm:recipe_type');
            switch (recipeType) {
                case RecipeType.NONE: {
                    block.dimension.spawnParticle('twb_farm:recipe_water', location);
                    break;
                }
                case RecipeType.BASE: {
                    block.dimension.spawnParticle('twb_farm:recipe_base', location);
                    break;
                }
                default: {
                    const recipeState = block.permutation.getState('twb_farm:recipe_state');
                    for (const [base, ingredients] of Object.entries(CookingPotModule.stewRecipes)) {
                        if (recipeType === base) {
                            if (recipeState > ingredients.length) {
                                if (this.hasFinishedCooking(block.location)) {
                                    block.dimension.spawnParticle('twb_farm:recipe_finished', location);
                                }
                            }
                            else {
                                block.dimension.spawnParticle('twb_farm:recipe_progress', location);
                                const particleName = base.split(':')[1];
                                block.dimension.spawnParticle(`twb_farm:recipe_${particleName}_${recipeState}`, location);
                            }
                            break;
                        }
                    }
                }
            }
        });
    }
    async spawnCookParticles(block, duration) {
        if (!block.permutation.matches('twb_farm:cooking_pot'))
            return;
        block.dimension.spawnParticle('twb_farm:recipe_progress', block.center());
        const interval = 10;
        if (duration > interval) {
            await sleep(interval);
            this.spawnCookParticles(block, duration - interval);
        }
    }
}
CookingPotModule.stewRecipes = {
    'minecraft:chicken': ['twb_farm:leek_item', 'twb_farm:garlic_item'],
    'minecraft:beef': ['minecraft:carrot', 'twb_farm:onion_item'],
    'twb_farm:rice_item': [],
    'minecraft:brown_mushroom': ['minecraft:red_mushroom'],
    'minecraft:rabbit': ['minecraft:potato', 'minecraft:carrot'],
};
